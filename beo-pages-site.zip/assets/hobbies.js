import * as THREE from '../vendor/three.module.js';
import {createInterestObject} from './interest-objects.js';

const prefs=()=>window.beoPreferences||{paused:false,reduced:false};
const cards=[...document.querySelectorAll('.hobby-card')];
const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,window.beoLite?1.15:1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.2;
renderer.domElement.className='hobby-renderer';renderer.domElement.setAttribute('aria-hidden','true');document.body.append(renderer.domElement);
function resize(){renderer.setSize(innerWidth,innerHeight,false);}addEventListener('resize',resize);resize();
const entries=cards.map(card=>{
  const target=card.querySelector('.hobby-visual'),button=card.querySelector('.hobby-play');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(34,1,.1,30);camera.position.set(0,.15,6);camera.lookAt(0,0,0);
  scene.add(new THREE.HemisphereLight(0xe6f2f4,0x333b3b,2));
  const key=new THREE.DirectionalLight(0xfff4df,3);key.position.set(-3,4,5);scene.add(key);
  const rim=new THREE.DirectionalLight(0xb7d1dc,3);rim.position.set(3,1,-2);scene.add(rim);
  const model=createInterestObject(card.dataset.hobby),root=new THREE.Group();root.add(model.group);scene.add(root);
  const entry={card,target,button,scene,camera,model,root,angle:0,desired:0,time:0,until:0};
  function activate(){entry.until=performance.now()+3800;card.classList.add('is-active');button.setAttribute('aria-pressed','true');}
  let down=false,startX=0,startY=0,base=0,moved=false;
  target.addEventListener('pointerdown',event=>{if(event.button!==0)return;down=true;moved=false;startX=event.clientX;startY=event.clientY;base=entry.desired;});
  target.addEventListener('pointermove',event=>{if(!down)return;const dx=event.clientX-startX,dy=event.clientY-startY;if(!moved&&Math.abs(dy)>Math.abs(dx)+7){down=false;return;}if(Math.abs(dx)>5){moved=true;target.setPointerCapture(event.pointerId);entry.desired=base+dx*.009;}});
  target.addEventListener('pointerup',()=>{down=false;});target.addEventListener('pointercancel',()=>down=false);target.addEventListener('lostpointercapture',()=>down=false);
  target.addEventListener('click',()=>{if(!moved)activate();});button.addEventListener('click',activate);
  target.addEventListener('keydown',event=>{if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();entry.desired+=(event.key==='ArrowRight'?1:-1)*.2;}});
  return entry;
});
let previous=0,frames=0;
function frame(now){
  requestAnimationFrame(frame);if(now-previous<33||document.hidden)return;const dt=Math.min(.06,(now-previous)/1000);previous=now;
  renderer.setScissorTest(false);renderer.setClearColor(0,0);renderer.clear();renderer.setScissorTest(true);
  for(const entry of entries){
    const r=entry.target.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight||!r.width||!r.height)continue;
    const active=now<entry.until,energy=active?Math.sin((1-(entry.until-now)/3800)*Math.PI):0;
    if(!active&&entry.card.classList.contains('is-active')){entry.card.classList.remove('is-active');entry.button.setAttribute('aria-pressed','false');}
    if((!prefs().paused&&!prefs().reduced)||active)entry.time+=dt;
    entry.angle=THREE.MathUtils.lerp(entry.angle,entry.desired,.12);entry.root.rotation.y=entry.angle;entry.root.position.y=Math.sin(entry.time*.65)*.035;
    entry.model.update(entry.time,prefs().reduced?0:energy);entry.camera.aspect=r.width/r.height;entry.camera.updateProjectionMatrix();
    renderer.setViewport(r.left,innerHeight-r.bottom,r.width,r.height);renderer.setScissor(Math.max(0,r.left),Math.max(0,innerHeight-r.bottom),Math.min(r.right,innerWidth)-Math.max(0,r.left),Math.min(r.bottom,innerHeight)-Math.max(0,r.top));renderer.render(entry.scene,entry.camera);
    entry.card.classList.add('is-rendered');entry.card.dataset.frame=String(++frames);
  }
  renderer.domElement.dataset.frames=String(frames);
}requestAnimationFrame(frame);
renderer.domElement.addEventListener('webglcontextlost',()=>cards.forEach(card=>card.classList.remove('is-rendered')));
