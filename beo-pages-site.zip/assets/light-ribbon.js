import * as THREE from '../vendor/three.module.js';

// Draw only the narrow strip swept by the pointer, in the sky's existing render pass.
export function lightRibbon(scene) {
  const count = 40;
  const positions = new Float32Array(count * 2 * 3);
  const uv = [], indices = [];
  for (let i = 0; i < count; i++) {
    uv.push(i / (count - 1), 0, i / (count - 1), 1);
    const a = i * 2;
    if (i) indices.push(a - 2, a - 1, a, a, a - 1, a + 1);
  }
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3).setUsage(THREE.DynamicDrawUsage));
  geometry.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2));
  geometry.setIndex(indices);
  const uniforms = { pale: {value: 0}, fade: {value: 0}, phase: {value: 0} };
  const material = new THREE.ShaderMaterial({
    transparent: true, depthTest: false, depthWrite: false, side: THREE.DoubleSide, uniforms,
    vertexShader: 'varying vec2 along; void main(){along=uv;gl_Position=vec4(position.xy,0.,1.);}',
    fragmentShader: `varying vec2 along;uniform float pale,fade,phase;
      void main(){
        float u=along.x,y=along.y*2.-1.;
        float wave=sin(u*8.+phase)*.34;
        float core=exp(-19.*abs(y-wave));
        float fold=exp(-9.*abs(y+.55*wave+.16));
        float haze=exp(-4.5*y*y)*(1.-smoothstep(.65,1.,abs(y)));
        float envelope=sin(3.14159*u);
        vec3 ink=mix(vec3(.33,.80,1.),vec3(.72,.45,1.),smoothstep(.0,.9,u));
        ink=mix(ink,vec3(.14,.19,.6),pale*.75);
        gl_FragColor=vec4(mix(ink,vec3(.91,.95,1.),core*.64*(1.-pale)),fade*envelope*(core*.77+fold*.38+haze*.16));
      }`
  });
  const mesh = new THREE.Mesh(geometry, material);
  mesh.frustumCulled = false;
  mesh.visible = false;
  mesh.renderOrder = 1;
  scene.add(mesh);
  const points = [];
  let current = null;
  function reset() { current = null; points.length = 0; mesh.visible = false; }
  return {
    reset,
    move(x, y) {
      const now = performance.now();
      if (!current || now - current.time > 400) reset();
      current = {x, y, time: now};
    },
    update(now, pale) {
      if (!current) return;
      const age = Math.max(0, now - current.time);
      if (age >= 740) { reset(); return; }
      points.unshift(current);
      if (points.length > count) points.pop();
      const n = points.length;
      if (n < 3) return;
      for (let i = 0; i < count; i++) {
        const point = points[Math.min(i, n-1)];
        const prev = points[Math.max(0, Math.min(i-1,n-1))];
        const next = points[Math.min(i+1,n-1)];
        const dx = prev.x-next.x, dy = prev.y-next.y;
        const speed = Math.hypot(dx,dy);
        const width = (4 + Math.min(speed*.32, 24)) * (.18 + .82*Math.sin(Math.PI*i/(count-1)));
        const nx = -dy/(speed || 1)*width, ny = dx/(speed || 1)*width;
        for (let side=0; side<2; side++) {
          const sign=side*2-1, offset=(i*2+side)*3;
          positions[offset]=(point.x+sign*nx)/innerWidth*2-1;
          positions[offset+1]=1-(point.y+sign*ny)/innerHeight*2;
        }
      }
      uniforms.pale.value = pale;
      uniforms.fade.value = 1-age/740;
      uniforms.phase.value = now*.0018;
      geometry.attributes.position.needsUpdate = true;
      mesh.visible = true;
    }
  };
}
