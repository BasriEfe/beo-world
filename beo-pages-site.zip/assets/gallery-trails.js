// Ribbons and sparks share one canvas so the photographs stay fully interactive.
export function galleryTrails(film, preferences) {
  const canvas=document.createElement('canvas');
  canvas.className='gallery-trails';
  canvas.setAttribute('aria-hidden','true');
  film.prepend(canvas);
  const context=canvas.getContext('2d');
  if(!context)return;
  let width=1,height=1,phase=0,previous=0;
  const bands=['#bca2f2','#c6a575','#807eac'];
  function paint(){
    context.clearRect(0,0,width,height);
    bands.forEach((color,band)=>{
      context.strokeStyle=color;
      context.fillStyle=color;
      context.beginPath();
      function position(t){
        const x=t*width;
        const y=height*(.72+.12*band-.34*t+.12*Math.sin(t*7.4+band*.46+phase));
        return [x,y];
      }
      for(let k=0;k<=100;k++){
        const [x,y]=position(k/100);
        if(k===0)context.moveTo(x,y);else context.lineTo(x,y);
      }
      context.globalAlpha=.33;
      context.stroke();
      for(let k=0;k<50;k++){
        const t=(k*.618034+phase*.045+band*.17)%1;
        const [x,y]=position(t);
        context.beginPath();
        context.globalAlpha=.25+.35*(1+Math.sin(k*2.4+phase))/2;
        context.arc(x,y+Math.sin(k*8.7)*Math.cos(k*1.7)*height*.075,.6+(k%5)*.19,0,Math.PI*2);
        context.fill();
      }
    });
  }
  new ResizeObserver(()=>{
    width=film.clientWidth;height=film.clientHeight;
    const scale=Math.min(devicePixelRatio,1.5);
    canvas.width=Math.round(width*scale);canvas.height=Math.round(height*scale);
    context.setTransform(scale,0,0,scale,0,0);paint();
  }).observe(film);
  function frame(time){
    if(time-previous>=40){
      const elapsed=Math.min(time-previous,100);
      previous=time;
      if(!document.hidden&&!preferences().paused&&!preferences().reduced&&!film.classList.contains('film-paused')&&!document.querySelector('#site-menu').open){
        phase+=elapsed*.00012;paint();
      }
    }
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
