import * as THREE from '../vendor/three.module.js';
import {createInterestObject} from './interest-objects.js';
const preferences=()=>window.beoPreferences||{paused:false,reduced:false,theme:'dark'};
const textureLoader=new THREE.TextureLoader();
const load=(file,colour=true)=>textureLoader.loadAsync('assets/textures/'+file).then(texture=>{if(colour)texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=4;return texture;});
const stage=document.querySelector('#world-stage');
if(stage)createWorld().catch(error=>{console.warn('3D scene unavailable; surface fallback retained.',error);stage.classList.add('fallback-mode');});
async function createWorld(){
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio||1,window.beoLite?1.25:1.6));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;renderer.setClearColor(0,0);
  stage.append(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(37,1,.1,50);camera.position.set(0,0,7.7);
  const system=new THREE.Group();system.rotation.z=-.12;scene.add(system);
  const sunVector=new THREE.Vector3(-.75,.85,1.08).normalize();
  const sun=new THREE.DirectionalLight(0xffffff,3.2);sun.position.copy(sunVector).multiplyScalar(8);scene.add(sun,new THREE.AmbientLight(0xc1d2df,.22));
  const [day,night,normal,cloudMap]=await Promise.all([load('earth-day-hd.jpg'),load('earth-night.jpg'),load('earth-normal.jpg',false),load('earth-clouds.png')]);
  const surfaceGeometry=new THREE.SphereGeometry(1.47,96,64);
  const material=new THREE.ShaderMaterial({uniforms:{dayMap:{value:day},nightMap:{value:night},normalMap:{value:normal},sunDirection:{value:sunVector}},vertexShader:`
    varying vec2 vUv; varying vec3 vNormal; varying vec3 vPosition;
    void main(){vUv=uv;vNormal=normalize(mat3(modelMatrix)*normal);vec4 p=modelMatrix*vec4(position,1.);vPosition=p.xyz;gl_Position=projectionMatrix*viewMatrix*p;}
  `,fragmentShader:`
    uniform sampler2D dayMap;uniform sampler2D nightMap;uniform sampler2D normalMap;uniform vec3 sunDirection;
    varying vec2 vUv;varying vec3 vNormal;varying vec3 vPosition;
    void main(){
      vec3 n=normalize(vNormal);
      vec3 q0=dFdx(vPosition),q1=dFdy(vPosition);vec2 st0=dFdx(vUv),st1=dFdy(vUv);
      vec3 tangent=normalize(q0*st1.y-q1*st0.y);vec3 bitangent=-normalize(cross(n,tangent));
      vec3 detail=texture2D(normalMap,vUv).xyz*2.-1.;detail.xy*=.16;
      n=normalize(mat3(tangent,bitangent,n)*detail);
      float light=dot(n,sunDirection);float sunlight=smoothstep(-.16,.26,light);
      vec3 daylight=texture2D(dayMap,vUv).rgb;
      daylight=mix(vec3(dot(daylight,vec3(.2126,.7152,.0722))),daylight,.73);
      float terrain=dot(daylight,vec3(.22,.63,.15));
      vec3 bluePrint=mix(daylight,vec3(.36,.58,1.22)*terrain,.66);
      vec3 colour=bluePrint*(.23+max(light,0.)*1.18)+vec3(.008,.017,.075);
      vec3 city=texture2D(nightMap,vUv).rgb;
      colour+=city*vec3(1.25,1.08,.82)*2.1*(1.-sunlight);
      vec3 viewDirection=normalize(cameraPosition-vPosition);
      float ocean=smoothstep(.015,.08,daylight.b-daylight.r);
      float spec=pow(max(dot(reflect(-sunDirection,n),viewDirection),0.),45.);
      colour+=vec3(.5,.62,.7)*spec*ocean*sunlight*.55;
      float rim=pow(1.-max(dot(normalize(vNormal),viewDirection),0.),3.8);
      colour+=mix(vec3(.17,.42,1.15),vec3(.33,.28,1.),smoothstep(-.65,.85,n.x))*rim*(.46+.54*sunlight);
      gl_FragColor=vec4(colour,1.);
      #include <tonemapping_fragment>
      #include <colorspace_fragment>
    }
  `});
  const earth=new THREE.Mesh(surfaceGeometry,material);earth.rotation.y=2.95;earth.rotation.x=.14;system.add(earth);
  const clouds=new THREE.Mesh(new THREE.SphereGeometry(1.482,80,48),new THREE.MeshPhongMaterial({map:cloudMap,transparent:true,opacity:.43,depthWrite:false,shininess:0}));clouds.rotation.copy(earth.rotation);system.add(clouds);
  const atmosphere=new THREE.Mesh(new THREE.SphereGeometry(1.51,64,48),new THREE.ShaderMaterial({uniforms:{sunDirection:{value:sunVector}},transparent:true,blending:THREE.AdditiveBlending,depthWrite:false,side:THREE.FrontSide,vertexShader:`varying vec3 n;varying vec3 p;void main(){n=normalize(mat3(modelMatrix)*normal);vec4 world=modelMatrix*vec4(position,1.);p=world.xyz;gl_Position=projectionMatrix*viewMatrix*world;}`,fragmentShader:`uniform vec3 sunDirection;varying vec3 n;varying vec3 p;void main(){float rim=pow(1.-max(dot(normalize(n),normalize(cameraPosition-p)),0.),4.);float light=smoothstep(-.3,.8,dot(normalize(n),sunDirection));gl_FragColor=vec4(.12,.35,1.,rim*light*.85);}`}));system.add(atmosphere);

  const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();
  window.beoWorldHitTest=(x,y)=>{const r=renderer.domElement.getBoundingClientRect();if(x<r.left||x>r.right||y<r.top||y>r.bottom)return false;mouse.set((x-r.left)/r.width*2-1,-(y-r.top)/r.height*2+1);raycaster.setFromCamera(mouse,camera);return raycaster.intersectObjects([earth],false).length>0;};
  let width=0,height=0,visible=true,dragging=false,lastX=0,lastY=0,rotation=earth.rotation.y,tilt=earth.rotation.x,time=0,lastFrame=0,frames=0;
  let framing=8;
  function resize(){const r=stage.getBoundingClientRect();width=r.width;height=r.height;renderer.setSize(width,height,false);camera.aspect=width/height;framing=Math.max(6.26,1.76/(Math.tan(THREE.MathUtils.degToRad(18.5))*camera.aspect));camera.position.z=framing;camera.updateProjectionMatrix();}
  new ResizeObserver(resize).observe(stage);resize();
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;},{rootMargin:'80px'}).observe(stage);
  stage.addEventListener('pointerdown',event=>{if(event.button!==0||!window.beoWorldHitTest(event.clientX,event.clientY))return;dragging=true;lastX=event.clientX;lastY=event.clientY;stage.setPointerCapture(event.pointerId);});
  stage.addEventListener('pointermove',event=>{if(!dragging)return;rotation+=(event.clientX-lastX)*.006;tilt=THREE.MathUtils.clamp(tilt+(event.clientY-lastY)*.003,-.6,.6);lastX=event.clientX;lastY=event.clientY;});
  stage.addEventListener('pointerup',()=>dragging=false);stage.addEventListener('pointercancel',()=>dragging=false);stage.addEventListener('lostpointercapture',()=>dragging=false);
  stage.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();if(event.key==='ArrowLeft')rotation-=.15;if(event.key==='ArrowRight')rotation+=.15;if(event.key==='ArrowUp')tilt=Math.max(-.6,tilt-.08);if(event.key==='ArrowDown')tilt=Math.min(.6,tilt+.08);});
  function animate(now){
    requestAnimationFrame(animate);if(now-lastFrame<(window.beoChapter&&!window.beoLite?15:33))return;
    const dt=Math.min(.08,(now-lastFrame)/1000);lastFrame=now;if(!visible||document.hidden)return;
    if(!preferences().paused&&!preferences().reduced&&!dragging){time+=dt;rotation+=dt*.025;}
    earth.rotation.y=THREE.MathUtils.lerp(earth.rotation.y,rotation,.14);earth.rotation.x=THREE.MathUtils.lerp(earth.rotation.x,tilt,.14);clouds.rotation.y=earth.rotation.y+time*.004;clouds.rotation.x=earth.rotation.x;
    const chapter=window.beoChapter,journey=chapter?0:window.beoHeroProgress||0,departure=chapter?.orbit||0;
    camera.position.z=framing-journey*.8-departure*.85;system.rotation.y=journey*.35+departure*.2;system.position.y=-.23+journey*.22;system.position.x=0-departure*.12;
    renderer.render(scene,camera);
    if(frames===0){
      stage.classList.add('is-ready');stage.dataset.loaded='true';
      const gl=renderer.getContext(),pixel=new Uint8Array(4);
      gl.readPixels(Math.floor(renderer.domElement.width*.5),Math.floor(renderer.domElement.height*.5),1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixel);
      stage.dataset.pixel=[...pixel].join(',');
    }
    stage.dataset.frame=String(++frames);
    if(frames%10===0)stage.dataset.rotation=earth.rotation.y.toFixed(3);
  }requestAnimationFrame(animate);
  renderer.domElement.addEventListener('webglcontextlost',()=>stage.classList.remove('is-ready'));
  renderer.domElement.addEventListener('webglcontextrestored',()=>stage.classList.add('is-ready'));
}

// One offscreen render context creates all category objects, instead of one GPU loop per card.
const objects=[...document.querySelectorAll('[data-object]')];
if(objects.length){try{renderObjects();}catch(error){console.warn('Category render fallback retained.',error);}}
function renderObjects(){
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,preserveDrawingBuffer:true,powerPreference:'low-power'});renderer.setSize(600,600);renderer.setPixelRatio(1);renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(32,1,.1,30);camera.position.set(0,.35,6.5);camera.lookAt(0,0,0);
  scene.add(new THREE.AmbientLight(0xffffff,1.3));
  const key=new THREE.DirectionalLight(0xf4f1de,4);key.position.set(-3,5,4);scene.add(key);
  const fill=new THREE.DirectionalLight(0x9eacae,2);fill.position.set(3,0,-2);scene.add(fill);
  const material=new THREE.MeshStandardMaterial({color:0x81abbc,metalness:.48,roughness:.28});
  const paper=new THREE.MeshStandardMaterial({color:0xd8d9cf,metalness:.1,roughness:.55});
  const dark=new THREE.MeshStandardMaterial({color:0x131919,metalness:.45,roughness:.35});
  const pale=new THREE.MeshStandardMaterial({color:0xd9ad70,metalness:.5,roughness:.3});
  const box=(x,y,z,mat=material)=>new THREE.Mesh(new THREE.BoxGeometry(x,y,z),mat);
  function tube(points,radius=.045,mat=material){return new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),40,radius,10,false),mat);}
  function make(kind){
    if(kind==='globe'){const object=createInterestObject('space');object.update(0,0);return object.group;}
    if(kind==='home')return createInterestObject('home').group;
    // 'i-' önekli objeler İlgi Alanlarım modellerini kullanır (örn. i-travel = uçak).
    if(kind.startsWith('i-')){const object=createInterestObject(kind.slice(2));object.update?.(0,0);return object.group;}
    if(kind==='knight'){const object=createInterestObject('chess');object.group.scale.setScalar(.85);return object.group;}
    const g=new THREE.Group();
    if(kind==='cap'){
      const crown=new THREE.Mesh(new THREE.CylinderGeometry(.59,.53,.54,64),dark);crown.position.y=-.15;g.add(crown);
      const top=box(1.65,.07,1.65);top.position.y=.16;top.rotation.y=.18;g.add(top);
      g.add(tube([[0,.23,0],[.6,.25,.1],[.85,.14,.2],[.93,-.38,.2]],.025,pale));
      const tassel=new THREE.Mesh(new THREE.CylinderGeometry(.05,.08,.3,20),pale);tassel.position.set(.93,-.5,.2);g.add(tassel);g.rotation.set(.35,-.5,-.12);
    }else if(kind==='code'){
      g.add(tube([[-.48,.7,0],[-1.05,0,0],[-.48,-.7,0]],.12),tube([[.48,.7,0],[1.05,0,0],[.48,-.7,0]],.12),tube([[.2,.9,.1],[-.2,-.9,.1]],.09,pale));g.rotation.set(-.13,-.38,-.08);
    }else if(kind==='camera'){
      const body=box(1.8,1.15,.65);g.add(body);
      const top=box(.65,.25,.55);top.position.set(-.2,.67,0);g.add(top);
      const grip=box(.28,.92,.12,dark);grip.position.set(-.65,0,.37);g.add(grip);
      const lens=new THREE.Mesh(new THREE.CylinderGeometry(.44,.49,.55,64),dark);lens.rotation.x=Math.PI/2;lens.position.z=.55;g.add(lens);
      const ring=new THREE.Mesh(new THREE.TorusGeometry(.38,.055,12,64),paper);ring.position.z=.85;g.add(ring);
      const glass=new THREE.Mesh(new THREE.CircleGeometry(.32,64),new THREE.MeshStandardMaterial({color:0x243c3a,metalness:.7,roughness:.12}));glass.position.z=.86;g.add(glass);
      const shutter=new THREE.Mesh(new THREE.CylinderGeometry(.1,.1,.08,20),paper);shutter.position.set(.62,.63,0);g.add(shutter);g.rotation.set(.1,-.43,-.09);
    }else if(kind==='book'){
      const sheets=box(1.2,1.65,.23,paper);g.add(sheets);const cover1=box(1.3,1.77,.07),cover2=cover1.clone();cover1.position.z=.17;cover2.position.z=-.17;g.add(cover1,cover2);
      const spine=box(.13,1.76,.35);spine.position.x=-.6;g.add(spine);
      for(let i=0;i<9;i++){const line=box(1.15,.007,.005,new THREE.MeshBasicMaterial({color:0x8d948b}));line.position.set(0,-.69+i*.17,.124);g.add(line);}
      const bookmark=box(.16,.5,.018,pale);bookmark.position.set(.3,-.75,.1);g.add(bookmark);g.rotation.set(.12,-.5,-.15);
    }else if(kind==='envelope'){
      const body=box(1.9,1.22,.12,paper);g.add(body);
      g.add(tube([[-.92,.58,.075],[0,-.1,.11],[.92,.58,.075]],.018,material),tube([[-.92,-.58,.075],[-.15,.0,.08]],.012,material),tube([[.92,-.58,.075],[.15,.0,.08]],.012,material));
      const seal=new THREE.Mesh(new THREE.CylinderGeometry(.13,.13,.03,40),pale);seal.rotation.x=Math.PI/2;seal.position.set(0,-.08,.14);g.add(seal);g.rotation.set(.13,-.3,.13);
    }return g;
  }
  const cache=new Map();
  objects.forEach(element=>{
    const kind=element.dataset.object;
    if(!cache.has(kind)){
      const group=make(kind);scene.add(group);renderer.render(scene,camera);cache.set(kind,renderer.domElement.toDataURL('image/png'));scene.remove(group);
      group.traverse(child=>{if(child.geometry)child.geometry.dispose();});
    }
    const img=new Image();img.alt='';img.decoding='async';img.src=cache.get(kind);element.append(img);element.classList.add('is-rendered');
  });
  renderer.dispose();renderer.forceContextLoss();
}
