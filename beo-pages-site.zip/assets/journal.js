import {notebook} from './book.js';
const reader=document.querySelector('#journal-reader');
if(reader){
  const archive=document.querySelector('.journal-archive'),cards=[...archive.querySelectorAll('.journal-card')],search=document.querySelector('#journal-search'),buttons=[...document.querySelectorAll('button[data-topic]')],content=reader.querySelector('.reader-content');
  let topic='all',lastFocus=null,ownsHistory=false;
  const lang=()=>window.beoPreferences?.language||'en';
  const refreshBook=notebook(archive.querySelector('.journal-grid'),cards,lang);
  const normalize=text=>text.toLocaleLowerCase('tr').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replaceAll('ı','i');
  const localize=root=>root.querySelectorAll('[data-tr][data-en]').forEach(el=>el.innerHTML=el.dataset[lang()]);
  function filter(){
    const term=normalize(search.value.trim());let count=0;
    cards.forEach(card=>{const matches=(topic==='all'||card.dataset.topic===topic)&&normalize(card.textContent).includes(term);card.hidden=!matches;if(matches)count++;});
    archive.classList.toggle('is-filtered',topic!=='all'||Boolean(term));
    archive.querySelector('.journal-empty').hidden=count!==0;
    refreshBook();
    document.querySelector('#journal-status').textContent=lang()==='tr'?`${count} yazı gösteriliyor.`:`${count} articles shown.`;
    buttons.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.topic===topic)));
    if(!window.beoPreferences?.reduced)cards.filter(card=>!card.hidden).forEach((card,i)=>{card.classList.remove('is-entering');requestAnimationFrame(()=>{card.style.animationDelay=`${Math.min(i,5)*35}ms`;card.classList.add('is-entering');});});
  }
  buttons.forEach(button=>button.addEventListener('click',()=>{topic=button.dataset.topic;filter();}));search.addEventListener('input',filter);
  archive.querySelector('[data-reset-search]').addEventListener('click',()=>{topic='all';search.value='';filter();search.focus();});
  const plateDesk=document.querySelector('#plate-desk');
  const loosePlates=plateDesk.querySelector('.loose-plates');
  archive.addEventListener('click',event=>{
    const button=event.target.closest('[data-plates]');
    if(!button)return;
    const i=cards.findIndex(card=>card.dataset.post===button.dataset.plates);
    const group=[cards[(i+cards.length-1)%cards.length],cards[(i+1)%cards.length],cards[i]];
    loosePlates.replaceChildren(...group.map(card=>{
      const print=document.createElement('button');
      print.type='button';
      const art=card.querySelector('.engraving').cloneNode();
      const title=document.createElement('span');
      title.textContent=card.querySelector('h2').textContent;
      print.append(art,title);
      print.addEventListener('click',()=>{
        plateDesk.close();
        open(card.dataset.post);
      });
      return print;
    }));
    plateDesk.showModal();
  });
  plateDesk.querySelector('.plate-close').addEventListener('click',()=>plateDesk.close());
  plateDesk.addEventListener('click',event=>{if(event.target===plateDesk)plateDesk.close();});
  function open(id,updateHash=true){
    const template=document.getElementById('post-'+id);if(!template)return false;
    const wasOpen=reader.open;if(!wasOpen)lastFocus=document.activeElement;
    content.replaceChildren(template.content.cloneNode(true));localize(content);reader.dataset.post=id;
    if(!reader.open)reader.showModal();document.body.classList.add('reading-post');reader.scrollTop=0;
    if(updateHash){if(!wasOpen){history.pushState(null,'','#'+id);ownsHistory=true;}else history.replaceState(null,'','#'+id);}
    document.title=content.querySelector('#reader-title').textContent+' | Journal | Basri Efe Özdemir';
    reader.querySelector('.reader-close').focus({preventScroll:true});reader.style.setProperty('--reading-progress',0);return true;
  }
  function close(updateHistory=true){reader.close();document.body.classList.remove('reading-post');document.title=(lang()==='tr'?document.body.dataset.titleTr:document.body.dataset.titleEn)+' | Basri Efe Özdemir';if(updateHistory){if(ownsHistory)history.back();else history.replaceState(null,'',location.pathname+location.search);}ownsHistory=false;lastFocus?.focus({preventScroll:true});}
  document.addEventListener('click',event=>{const link=event.target.closest('[data-read]');if(!link||event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;event.preventDefault();open(link.dataset.read);});
  reader.querySelector('.reader-close').addEventListener('click',()=>close());
  reader.addEventListener('cancel',event=>{event.preventDefault();close();});
  reader.addEventListener('scroll',()=>{const range=reader.scrollHeight-reader.clientHeight;reader.style.setProperty('--reading-progress',range?reader.scrollTop/range:0);},{passive:true});
  reader.addEventListener('click',event=>{const link=event.target.closest('.reader-toc a');if(!link)return;event.preventDefault();const target=reader.querySelector(link.getAttribute('href'));target?.scrollIntoView({behavior:window.beoPreferences?.reduced?'instant':'smooth',block:'start'});});
  addEventListener('beo-preferences',()=>{if(reader.open){localize(content);document.title=content.querySelector('#reader-title').textContent+' | Journal | Basri Efe Özdemir';}filter();});
  addEventListener('hashchange',()=>{const id=location.hash.slice(1);if(id)open(id,false);else if(reader.open)close(false);});
  filter();if(location.hash)open(location.hash.slice(1),false);
  const visibility=new IntersectionObserver(entries=>entries.forEach(entry=>entry.target.classList.toggle('is-offscreen',!entry.isIntersecting)),{rootMargin:'80px'});
  document.querySelectorAll('.journal-art').forEach(art=>visibility.observe(art));
}
