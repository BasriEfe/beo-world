// ---------------------------------------------------------------------------
// home.js — Ana sayfa / Keşfet: listedeki bir bölümün üzerine gelince ya da
// klavyeyle odaklanınca sağdaki büyük önizleme o bölüme geçer.
// ---------------------------------------------------------------------------
const list=document.querySelector('.kesfet-list');
const layers=[...document.querySelectorAll('.preview-layer')];
if(list&&layers.length){
  const rows=[...list.querySelectorAll('.kesfet-row')];
  function show(index){
    layers.forEach(layer=>layer.classList.toggle('is-active',layer.dataset.layer===String(index)));
    rows.forEach(row=>row.classList.toggle('is-active',row.dataset.preview===String(index)));
  }
  rows.forEach(row=>{
    row.addEventListener('pointerenter',()=>show(row.dataset.preview));
    row.addEventListener('focus',()=>show(row.dataset.preview));
  });
  show(0);
}
