const section=document.querySelector('.journey-section');
if(section)init().catch(error=>{console.warn('Journey map unavailable.',error);section.classList.add('map-failed');section.querySelector('.journey-network').hidden=false;});

async function init(){
  if(!window.maplibregl){
    const script=document.querySelector('script[src="vendor/maplibre-gl.js"]');
    await new Promise((resolve,reject)=>{script.addEventListener('load',resolve,{once:true});script.addEventListener('error',reject,{once:true});setTimeout(()=>window.maplibregl?resolve():reject(Error('Map library did not load')),8000);});
  }
  const gl=window.maplibregl,prefs=()=>window.beoPreferences||{theme:'dark',language:'en',paused:false,reduced:false};
  const local=(tr,en)=>prefs().language==='tr'?tr:en;
  const container=document.querySelector('#journey-map'),frame=section.querySelector('.journey-map-frame'),toggle=section.querySelector('.journey-toggle');
  const data=await fetch('assets/journey-provinces.geojson').then(response=>{if(!response.ok)throw Error('Province data unavailable');return response.json();});
  const boundsFor=feature=>{
    const bounds=new gl.LngLatBounds();
    function visit(coords){if(typeof coords[0]==='number')bounds.extend(coords);else coords.forEach(visit);}visit(feature.geometry.coordinates);return bounds;
  };
  const provinces=Object.fromEntries(data.features.map(feature=>[feature.properties.id,boundsFor(feature)]));
  const stops={
    overview:{title:()=>local('Türkiye ve komşuları','Türkiye and its neighbours'),bounds:[[23.2,33],[47.2,44.8]],bearing:0,pitch:0},
    istanbul:{title:()=> 'İstanbul',subtitle:()=>local('Aslen İstanbulluyum','Where I’m originally from'),point:[28.9784,41.0082],bounds:provinces.istanbul,bearing:-8,pitch:15},
    antalya:{title:()=> 'Antalya',subtitle:()=>local('Büyüdüğüm şehir','Where I grew up'),point:[30.705,36.885],bounds:provinces.antalya,bearing:3,pitch:12},
    genclik:{title:()=>local('Gençlik Mahallesi','Gençlik neighbourhood'),subtitle:()=> 'Muratpaşa · Antalya',point:[30.7120259,36.8756718],bounds:provinces.genclik,bearing:-6,pitch:25},
    campus:{title:()=>local('Akdeniz Üniversitesi','Akdeniz University'),subtitle:()=>local('Bilgisayar Programcılığı','Computer Programming'),point:[30.6508866,36.8938473],bounds:provinces.campus,bearing:-12,pitch:35}
  };
  const steps=[{id:'overview',duration:0,hold:1200},{id:'istanbul',duration:4200,hold:2600},{id:'overview',duration:2600,hold:450},{id:'antalya',duration:4200,hold:2600},{id:'genclik',duration:3600,hold:2600},{id:'campus',duration:4200,hold:1600}];
  let theme=prefs().theme,ready=false,visible=false,everStarted=false,userPaused=false,playing=false,finished=false,epoch=0,index=0,phase='travel',remaining=null,deadline=0,cancelCurrent=null,current='overview',resumeAfterStyle=false,cycles=0;
  const styleURL=()=>`https://tiles.openfreemap.org/styles/${theme==='dark'?'dark':'liberty'}`;
  const map=new gl.Map({container,style:styleURL(),center:[35.2,39],zoom:4.3,minZoom:3,maxZoom:18,scrollZoom:false,cooperativeGestures:true,attributionControl:false,antialias:true,renderWorldCopies:false,dragRotate:false,touchPitch:false,fadeDuration:350});
  map.on('styleimagemissing',event=>{if(!['circle-11','wood-pattern'].includes(event.id)||map.hasImage(event.id))return;const pattern=event.id==='wood-pattern',size=pattern?16:11,pixels=new Uint8Array(size*size*4);for(let y=0;y<size;y++)for(let x=0;x<size;x++){const offset=(y*size+x)*4,inside=pattern?(x+y)%8<2:Math.hypot(x-5,y-5)<4;pixels[offset]=pixels[offset+1]=pixels[offset+2]=255;pixels[offset+3]=inside?(pattern?45:255):0;}map.addImage(event.id,{width:size,height:size,data:pixels},{sdf:!pattern});});
  map.addControl(new gl.AttributionControl({compact:true}),'bottom-right');
  new ResizeObserver(()=>map.resize()).observe(frame);
  const callout=document.createElement('div');callout.className='journey-callout';callout.innerHTML='<span class="journey-pin-dot"></span><span class="journey-connector"></span><div class="journey-place-label"><strong></strong><span></span></div>';
  const marker=new gl.Marker({element:callout,anchor:'center'});
  const smooth=t=>t*t*(3-2*t);

  function updateControls(){
    toggle.querySelector('i').className='fas fa-'+(playing?'pause':'play');
    toggle.setAttribute('aria-label',playing?local('Harita animasyonunu durdur','Pause map animation'):local('Harita animasyonunu sürdür','Resume map animation'));
    toggle.setAttribute('aria-pressed',String(!playing));section.dataset.playing=String(playing);
    container.setAttribute('aria-label',local('İstanbul, Antalya ve Akdeniz Üniversitesi haritası','Map of Istanbul, Antalya and Akdeniz University'));
  }
  function destination(id){
    const stop=stops[id],small=frame.clientWidth<600;
    const padding=id==='overview'?{top:35,bottom:35,left:25,right:25}:{top:75,bottom:60,left:small?35:100,right:small?90:230};
    if(stop.bounds)return {...map.cameraForBounds(stop.bounds,{padding,bearing:stop.bearing,maxZoom:id==='overview'?5.5:id==='campus'||id==='genclik'?16:10}),pitch:stop.pitch,bearing:stop.bearing};
    return {center:stop.center,zoom:small?15.1:stop.zoom,pitch:stop.pitch,bearing:stop.bearing,padding:{top:0,bottom:0,left:0,right:small?55:150}};
  }
  function layers(){
    if(map.getSource('journey-provinces'))return;
    map.addSource('journey-provinces',{type:'geojson',data});
    map.addLayer({id:'journey-province-fill',type:'fill',source:'journey-provinces',filter:['==',['get','id'],'none'],paint:{'fill-color':'#e35b58','fill-opacity':0,'fill-opacity-transition':{duration:850}}});
    map.addLayer({id:'journey-province-line',type:'line',source:'journey-provinces',filter:['==',['get','id'],'none'],paint:{'line-color':'#ed625f','line-width':['interpolate',['linear'],['zoom'],4,1,9,2.4],'line-opacity':0,'line-opacity-transition':{duration:850}}});
    const source=map.getSource('openmaptiles');
    if(source&&!map.getLayer('journey-campus-buildings')){
      const labels=map.getStyle().layers.find(layer=>layer.type==='symbol'&&layer.layout?.['text-field']);
      map.addLayer({id:'journey-campus-buildings',type:'fill-extrusion',source:'openmaptiles','source-layer':'building',minzoom:14,paint:{'fill-extrusion-color':theme==='dark'?'#4c5b5f':'#c9cfca','fill-extrusion-height':['coalesce',['get','render_height'],8],'fill-extrusion-base':['coalesce',['get','render_min_height'],0],'fill-extrusion-opacity':.68}},labels?.id);
    }
    showStage(current,true);
  }
  function highlight(id){
    if(!map.getLayer('journey-province-line'))return;
    const city=['istanbul','antalya','genclik','campus'].includes(id);
    if(city){map.setFilter('journey-province-fill',['==',['get','id'],id]);map.setFilter('journey-province-line',['==',['get','id'],id]);}
    map.setPaintProperty('journey-province-fill','fill-opacity',city ? .12 : 0);map.setPaintProperty('journey-province-line','line-opacity',city?1:0);
    section.dataset.highlight=city?id:'none';
  }
  function showStage(id,instant=false){
    current=id;section.dataset.stage=id;highlight(id);
    section.querySelector('[data-journey-stage]').textContent=stops[id].title();
    section.querySelectorAll('[data-stop]').forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.stop===id)));
    callout.classList.remove('is-visible');
    if(id!=='overview'){
      callout.querySelector('strong').textContent=stops[id].title();callout.querySelector('.journey-place-label>span').textContent=stops[id].subtitle();
      marker.setLngLat(stops[id].point).addTo(map);
      requestAnimationFrame(()=>callout.classList.add('is-visible'));
    }else marker.remove();
    if(instant)callout.classList.add('no-transition');else callout.classList.remove('no-transition');
  }
  function cancel(){cancelCurrent?.();cancelCurrent=null;map.stop();}
  function pause(byUser=false){
    if(byUser)userPaused=true;
    if(playing)remaining=Math.max(0,deadline-performance.now());
    playing=false;epoch++;cancel();updateControls();
  }
  function wait(ms){
    deadline=performance.now()+ms;
    return new Promise(resolve=>{let done=false;const finish=value=>{if(done)return;done=true;clearTimeout(timer);cancelCurrent=null;resolve(value);};const timer=setTimeout(()=>finish(true),ms);cancelCurrent=()=>finish(false);});
  }
  function travel(id,duration){
    callout.classList.remove('is-visible');
    if(id==='campus'||id==='genclik'||id==='overview')highlight('none');
    section.querySelector('[data-journey-stage]').textContent=stops[id].title();
    deadline=performance.now()+duration;
    return new Promise(resolve=>{
      let done=false,timer;
      const complete=value=>{if(done)return;done=true;clearTimeout(timer);map.off('moveend',onEnd);cancelCurrent=null;resolve(value);};
      const onEnd=()=>complete(true);map.once('moveend',onEnd);cancelCurrent=()=>complete(false);
      map.flyTo({...destination(id),duration,easing:smooth,essential:false});
      if(duration===0)complete(true);else timer=setTimeout(()=>complete(true),duration+500);
    });
  }
  async function run(){
    if(!ready||playing||prefs().paused||prefs().reduced||!visible||document.hidden)return;
    playing=true;userPaused=false;finished=false;everStarted=true;const token=++epoch;updateControls();
    while(token===epoch){
      if(index>=steps.length){cycles++;section.dataset.cycles=String(cycles);section.dataset.complete='true';index=0;phase='loop-hold';remaining=2200;}
      if(phase==='loop-hold'){if(!await wait(remaining??2200)||token!==epoch)return;remaining=null;phase='travel';section.dataset.complete='false';}
      const step=steps[index];
      if(phase==='travel'){
        const duration=remaining??(index===0&&cycles>0?3600:step.duration);remaining=null;
        if(!await travel(step.id,duration)||token!==epoch)return;
        showStage(step.id);phase='hold';
      }
      const hold=remaining??step.hold;remaining=null;
      if(!await wait(hold)||token!==epoch)return;
      index++;phase='travel';
    }
  }
  function replay(){pause();index=0;phase='travel';remaining=null;finished=false;cycles=0;userPaused=false;section.dataset.complete='false';showStage('overview');map.jumpTo(destination('overview'));if(prefs().paused||prefs().reduced){showStage('overview');return;}run();}
  async function select(id){
    if(!ready)return;pause(true);index=steps.findIndex(step=>step.id===id);phase='hold';remaining=steps[index].hold;const token=epoch;
    await travel(id,prefs().reduced||prefs().paused?0:1800);if(epoch===token)showStage(id);
  }
  toggle.addEventListener('click',()=>{if(playing)pause(true);else if(finished)replay();else{userPaused=false;run();}});
  section.querySelector('.journey-replay').addEventListener('click',replay);
  section.querySelectorAll('[data-stop]').forEach(button=>button.addEventListener('click',()=>{frame.scrollIntoView({block:'center',behavior:prefs().reduced?'instant':'smooth'});select(button.dataset.stop);}));
  section.querySelector('.journey-zoom-in').addEventListener('click',()=>{pause(true);map.zoomIn({duration:prefs().reduced?0:450});});
  section.querySelector('.journey-zoom-out').addEventListener('click',()=>{pause(true);map.zoomOut({duration:prefs().reduced?0:450});});
  map.on('dragstart',()=>pause(true));map.on('rotatestart',event=>{if(event.originalEvent)pause(true);});
  map.on('zoomstart',event=>{if(event.originalEvent)pause(true);});
  map.on('load',()=>{
    ready=true;section.classList.add('map-ready');section.dataset.loaded='true';map.jumpTo(destination('overview'));layers();
    if(visible&&!prefs().paused&&!prefs().reduced&&!userPaused)run();
    updateControls();
  });
  map.on('style.load',()=>{if(ready){layers();if(resumeAfterStyle){resumeAfterStyle=false;run();}}});
  let failedRequests=0;
  map.on('error',()=>{failedRequests++;if(!ready&&failedRequests>2){section.querySelector('.journey-network').hidden=false;section.classList.add('map-failed');}});
  map.on('idle',()=>{if(ready){section.classList.remove('map-failed');section.querySelector('.journey-network').hidden=true;}});
  new IntersectionObserver(entries=>{
    visible=entries[0].isIntersecting&&entries[0].intersectionRatio>=.5;
    if(!visible)pause();else if(!userPaused&&!finished)run();
  },{threshold:[0,.5]}).observe(frame);
  addEventListener('visibilitychange',()=>{if(document.hidden)pause();else if(visible&&!userPaused&&!finished)run();});
  addEventListener('beo-preferences',()=>{
    if(prefs().paused||prefs().reduced)pause();
    if(theme!==prefs().theme){resumeAfterStyle=playing;pause();theme=prefs().theme;map.setStyle(styleURL());}
    else if(!prefs().paused&&!prefs().reduced&&visible&&!userPaused&&!finished)run();
    if(ready)showStage(current,true);updateControls();
  });
  function progress(now){
    requestAnimationFrame(progress);if(!playing||document.hidden)return;
    const step=steps[Math.min(index,steps.length-1)],duration=phase==='travel'?step.duration:step.hold,portion=duration?1-Math.min(1,Math.max(0,deadline-now)/duration):1;
    const value=Math.min(1,(index+(phase==='travel'?portion*.7:.7+portion*.3))/steps.length);
    section.querySelector('.journey-progress').style.setProperty('--map-progress',value);
  }requestAnimationFrame(progress);
  updateControls();
  setTimeout(()=>{if(!ready){section.classList.add('map-failed');section.querySelector('.journey-network').hidden=false;}},18000);
}
