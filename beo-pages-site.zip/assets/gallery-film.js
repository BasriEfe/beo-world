const film=document.querySelector('.gallery-film');
const preferences=()=>window.beoPreferences||{language:'en',theme:'dark',paused:false,reduced:false};
const local=(tr,en)=>preferences().language==='tr'?tr:en;
const {cities}=await fetch('assets/gallery-tour.json'+new URL(import.meta.url).search).then(response=>{
  if(!response.ok)throw Error('Gallery manifest unavailable');return response.json();
});
const slides=[];
cities.forEach((city,cityIndex)=>{
  const photographs=city.media.filter(item=>!item.poster);
  for(let i=0;i<photographs.length;i+=2)slides.push({city,cityIndex,items:photographs.slice(i,i+2),duration:6200});
  city.media.filter(item=>item.poster).forEach(item=>slides.push({city,cityIndex,items:[item],duration:item.duration*1000}));
});
const menu=document.querySelector('#site-menu');
const toggle=film.querySelector('.film-toggle');
const fallback=film.querySelector('.gallery-fallback');
const cityButtons=[...film.querySelectorAll('[data-film-stop]')];
let touring=true;
let index=0,paused=false,scene=null,elapsed=0,clock=0,last=0,previousPaint=0,position=0,target=0;

function playing(){return !paused&&!preferences().paused&&!preferences().reduced&&!document.hidden&&!menu.open;}
function translate(){
  const slide=slides[index];
  film.querySelector('[data-film-chapter]').textContent=String(slide.cityIndex+1).padStart(2,'0')+' / '+String(cities.length).padStart(2,'0');
  film.querySelector('[data-film-city]').textContent=Array.isArray(slide.city.name)?local(...slide.city.name):slide.city.name;
  film.querySelector('[data-film-caption]').textContent=slide.items.map(item=>local(...item.caption)).join(' · ');
  film.querySelector('[data-film-count]').textContent=String(index+1).padStart(2,'0')+' / '+String(slides.length).padStart(2,'0');
  film.querySelector('.film-next').setAttribute('aria-label',local('Sonraki fotoğraf','Next photograph'));
  film.querySelector('.film-previous').setAttribute('aria-label',local('Önceki fotoğraf','Previous photograph'));
  const tourRunning=touring&&playing();
  toggle.setAttribute('aria-label',tourRunning?local('Galeriyi durdur','Pause gallery'):local('Galeriyi oynat','Play gallery'));
  toggle.querySelector('i').className='fas fa-'+(tourRunning?'pause':'play');
  toggle.setAttribute('aria-pressed',String(!tourRunning));
  cityButtons.forEach((button,i)=>{
    if(i===slide.cityIndex)button.setAttribute('aria-current','step');else button.removeAttribute('aria-current');
  });
  const accessible=film.querySelector('.gallery-accessible');
  accessible.replaceChildren(...slide.items.map(item=>{
    const image=new Image();image.src='assets/gallery/'+(item.poster||item.src);image.alt=local(...item.caption);return image;
  }));
}
function fallbackMedia(slide){
  fallback.querySelectorAll('video').forEach(video=>video.pause());
  fallback.replaceChildren(...slide.items.map(item=>{
    const media=document.createElement(item.poster?'video':'img');
    if(item.poster){media.muted=media.defaultMuted=true;media.playsInline=true;media.poster='assets/gallery/'+item.poster;media.preload='auto';if(playing())media.play().catch(()=>{});}
    else media.alt=local(...item.caption);
    media.src='assets/gallery/'+item.src;return media;
  }));
}
function show(){
  const slide=slides[index];
  film.dataset.frame=String(index);film.dataset.city=slide.city.id;
  translate();
  if(!scene)fallbackMedia(slide);
}
function go(next){
  touring=false;
  target+=next-index;
  elapsed=0;translate();
  if(preferences().reduced||preferences().paused){position=target;normalize();index=Math.round(position)%slides.length;show();}
}
function normalize(){
  while(position>=slides.length){position-=slides.length;target-=slides.length;}
  while(position<0){position+=slides.length;target+=slides.length;}
}
film.querySelector('.film-next').addEventListener('click',()=>go(index+1));
film.querySelector('.film-previous').addEventListener('click',()=>go(index-1));
cityButtons.forEach(button=>button.addEventListener('click',()=>go(slides.findIndex(slide=>slide.cityIndex===Number(button.dataset.filmStop)))));
toggle.addEventListener('click',()=>{
  if(preferences().paused)document.querySelector('.motion-toggle').click();
  if(preferences().reduced){go(index+1);return;}
  const running=touring&&!paused;
  touring=!running;paused=running;elapsed=0;translate();
});
let touch=null;
film.addEventListener('wheel',event=>{
  if(event.ctrlKey||menu.open)return;event.preventDefault();
  touring=false;
  const delta=(Math.abs(event.deltaX)>Math.abs(event.deltaY)?event.deltaX:event.deltaY)*(event.deltaMode===1?16:1);
  target+=Math.max(-1.2,Math.min(1.2,delta/340));elapsed=0;translate();
},{passive:false});
film.addEventListener('pointerdown',event=>{
  if(event.button!==0||event.target.closest('button,a'))return;
  touch={x:event.clientX,y:event.clientY};
});
film.addEventListener('pointerup',event=>{
  if(!touch)return;
  const dx=event.clientX-touch.x,dy=event.clientY-touch.y;touch=null;
  if(Math.max(Math.abs(dx),Math.abs(dy))<38)return;
  touring=false;
  go(index+((Math.abs(dx)>Math.abs(dy)?-dx:-dy)>0?1:-1));translate();
});
film.addEventListener('pointercancel',()=>touch=null);
addEventListener('keydown',event=>{
  if(menu.open||event.target.closest('button,a,input,textarea,dialog'))return;
  if(!['ArrowRight','ArrowLeft','ArrowDown','ArrowUp',' '].includes(event.key))return;
  event.preventDefault();touring=false;
  go(index+(['ArrowLeft','ArrowUp'].includes(event.key)?-1:1));translate();
});
addEventListener('beo-preferences',translate);
new MutationObserver(translate).observe(menu,{attributes:true,attributeFilter:['open']});
addEventListener('visibilitychange',translate);
function tick(now){
  requestAnimationFrame(tick);
  const dt=last?Math.min(80,now-last):0;last=now;
  const active=playing();
  if(!menu.open&&!document.hidden){
    const moving=Math.abs(target-position)>.001;
    if(preferences().paused||preferences().reduced)position=target;
    else position+=(target-position)*(1-Math.exp(-dt*.009));
    normalize();
    film.classList.toggle('space-travelling',moving);
    const next=Math.round(position)%slides.length;
    if(next!==index){index=next;show();}
    if(active&&touring&&!moving){elapsed+=dt;if(elapsed>=slides[index].duration){target+=1;elapsed=0;}}
  }
  if(active)clock+=dt*.001;
  if(now-previousPaint<33)return;
  previousPaint=now;
  scene?.render(clock,position,index,active,preferences().theme==='light');
  film.style.setProperty('--gallery-progress',String(elapsed/slides[index].duration));
  for(const video of fallback.querySelectorAll('video')){
    if(active&&video.paused&&!video.ended)video.play().catch(()=>{});
    if(!active&&!video.paused)video.pause();
  }
}
show();
requestAnimationFrame(tick);
if(!matchMedia('(max-width: 760px)').matches){
  let pendingScene;
  try{
    const {createGallerySpace}=await import('./gallery-space.js'+new URL(import.meta.url).search);
    const container=film.querySelector('.gallery-canvas');
    pendingScene=await createGallerySpace(container);
    await pendingScene.setSlides(slides);
    scene=pendingScene;
    container.querySelector('canvas').addEventListener('webglcontextlost',()=>{
      scene=null;
      film.classList.remove('space-ready');
      pendingScene.destroy();
      show();
    },{once:true});
    film.classList.add('space-ready');
    fallback.querySelectorAll('video').forEach(video=>video.pause());
    fallback.replaceChildren();
  }catch(error){
    pendingScene?.destroy();
    console.warn('3D gallery unavailable; photographs remain accessible.',error);
  }
}
addEventListener('pagehide',()=>{scene?.destroy();fallback.querySelectorAll('video').forEach(video=>video.pause());},{once:true});
