import * as THREE from '../vendor/three.module.js';
export async function createGallerySpace(container){
  const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,window.beoLite?1.2:1.6));renderer.outputColorSpace=THREE.SRGBColorSpace;
  renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.25;
  // Van Gogh esintili gökyüzü: fırça darbelerinden oluşan girdaplar, 2B tuvalde bir kez çizilir.
  const sky=document.createElement('canvas');sky.className='vg-sky';sky.setAttribute('aria-hidden','true');
  Object.assign(sky.style,{position:'absolute',inset:'0',width:'100%',height:'100%'});
  container.append(sky);
  renderer.domElement.style.position='relative';
  container.append(renderer.domElement);
  function paintSky(){
    const w=container.clientWidth,h=container.clientHeight;if(!w||!h)return;
    const dpr=Math.min(devicePixelRatio||1,1.5);sky.width=w*dpr;sky.height=h*dpr;
    const c=sky.getContext('2d');c.setTransform(dpr,0,0,dpr,0,0);
    const light=document.documentElement.dataset.theme==='light';
    const g=c.createLinearGradient(0,0,0,h);
    if(light){g.addColorStop(0,'#dfe8ff');g.addColorStop(1,'#a9c1ee');}else{g.addColorStop(0,'#0a1330');g.addColorStop(.55,'#13285e');g.addColorStop(1,'#1f4384');}
    c.fillStyle=g;c.fillRect(0,0,w,h);
    // Girdap merkezleri (yıldızlar ve büyük kıvrım)
    const swirls=[[w*.28,h*.32,1.0],[w*.62,h*.22,.8],[w*.8,h*.55,.6],[w*.45,h*.62,.7]];
    let seed=7;const rnd=()=>(seed=(seed*16807)%2147483647)/2147483647;
    const flow=(x,y)=>{let vx=1,vy=Math.sin(x*.006+y*.004)*.35;
      for(const [cx,cy,k] of swirls){const dx=x-cx,dy=y-cy,d2=dx*dx+dy*dy+900,f=k*6000/d2;vx+=-dy*f/40;vy+=dx*f/40;}
      const l=Math.hypot(vx,vy)||1;return [vx/l,vy/l];};
    const blues=light?['#7f9ee0','#a9c3f2','#c9daf7','#5f86d6','#ffffff']:['#1b3a7a','#24488f','#2f5fae','#3d6bb8','#4f7cc4','#7aa3e0','#a9c8f0'];
    c.lineCap='round';
    const strokes=Math.round(w*h/260);
    for(let i=0;i<strokes;i++){
      let x=rnd()*w,y=rnd()*h;c.beginPath();c.moveTo(x,y);
      for(let k=0;k<7;k++){const [ux,uy]=flow(x,y);x+=ux*5;y+=uy*5;c.lineTo(x,y);}
      c.strokeStyle=blues[Math.floor(rnd()*blues.length)];c.globalAlpha=.16+rnd()*.3;c.lineWidth=2.2+rnd()*3;c.stroke();
    }
    // Yıldızlar: sarı halkalarla çevrili parlak noktalar
    const stars=[[w*.28,h*.32,46],[w*.62,h*.22,32],[w*.8,h*.55,26],[w*.12,h*.15,20],[w*.9,h*.12,38]];
    for(const [x,y,r] of stars){
      for(let ring=r;ring>4;ring-=5){c.beginPath();c.arc(x,y,ring,0,Math.PI*2);c.strokeStyle=ring>r*.6?'#f2c14e':'#fff3c2';c.globalAlpha=.25+.5*(1-ring/r);c.lineWidth=2.4;c.stroke();}
      c.globalAlpha=1;c.fillStyle='#fff6d6';c.beginPath();c.arc(x,y,4,0,Math.PI*2);c.fill();
    }
    c.globalAlpha=1;
    // Yazıların okunması için solda, üstte (header'a geçiş) ve altta yumuşak bir koyulaşma
    const shade=light?'223,232,255':'10,19,48';
    let v=c.createLinearGradient(0,0,w*.38,0);v.addColorStop(0,`rgba(${shade},.72)`);v.addColorStop(1,`rgba(${shade},0)`);c.fillStyle=v;c.fillRect(0,0,w*.38,h);
    v=c.createLinearGradient(0,0,0,h*.18);v.addColorStop(0,`rgba(${shade},.8)`);v.addColorStop(1,`rgba(${shade},0)`);c.fillStyle=v;c.fillRect(0,0,w,h*.18);
    v=c.createLinearGradient(0,h,0,h*.7);v.addColorStop(0,`rgba(${shade},.75)`);v.addColorStop(1,`rgba(${shade},0)`);c.fillStyle=v;c.fillRect(0,h*.7,w,h*.3);
  }
  addEventListener('beo-preferences',paintSky);
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(48,1,.1,100);
  // Gün batımı teması (Kasım 2026): sıcak ışıklar, hafif sis; arka plan CSS'te degrade.
  scene.fog=new THREE.FogExp2(0x13285e,.02);
  scene.add(new THREE.HemisphereLight(0xfff0c8,0x13285e,2.2));
  const key=new THREE.PointLight(0xffd27a,90,50);key.position.set(4,3,6);scene.add(key);
  const fill=new THREE.PointLight(0x6fa8ff,70,50);fill.position.set(-4,-6,2);scene.add(fill);
  const gold=new THREE.PointLight(0xf2c14e,70,50);gold.position.set(3,-18,4);scene.add(gold);
  const shaft=new THREE.Group();scene.add(shaft);
  const pitch=2.35,step=Math.PI/3;
  let slides=[],panels=[],videos=[],active=-1,generation=0,disposed=false;
  const gates=[];
  const cache=new Map(),loader=new THREE.TextureLoader();
  const frameMaterial=new THREE.MeshStandardMaterial({color:0xd9a441,metalness:.85,roughness:.3,emissive:0x6b4a10,emissiveIntensity:.35}); // müze çerçevesi gibi altın
  // Translucent veils sit behind the photographs; their folds catch light as the camera passes.
  const veilGeometry=new THREE.PlaneGeometry(10,7);
  const veilMaterial=new THREE.ShaderMaterial({
    transparent:true,depthWrite:false,side:THREE.DoubleSide,
    uniforms:{clock:{value:0}},
    vertexShader:`varying vec2 vUv;varying float phase;
      void main(){vUv=uv;phase=modelMatrix[3].y;
      gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,
    fragmentShader:`varying vec2 vUv;varying float phase;uniform float clock;
      void main(){
        vec2 p=vUv*2.-1.;float t=clock*.12+phase;
        float glow=exp(-2.6*dot(p*vec2(.8,1.1),p*vec2(.8,1.1)));
        vec3 pigment=mix(vec3(.95,.78,.35),vec3(.45,.62,.98),.5+.5*sin(1.4*p.x+t));
        gl_FragColor=vec4(pigment,glow*.18);}`
  });
  function rail(width,height){
    const points=[[-width/2,-height/2,0],[width/2,-height/2,0],[width/2,height/2,0],[-width/2,height/2,0],[-width/2,-height/2,0]].map(p=>new THREE.Vector3(...p));
    const path=new THREE.CurvePath();for(let i=0;i<4;i++)path.add(new THREE.LineCurve3(points[i],points[i+1]));
    return new THREE.Mesh(new THREE.TubeGeometry(path,48,.02,6,false),frameMaterial);
  }
  async function texture(item){
    const file=item.poster||item.src;
    if(!cache.has(file))cache.set(file,loader.loadAsync('assets/gallery/'+file).then(texture=>{
      texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);
      return {texture,aspect:texture.image.width/texture.image.height};
    }));return cache.get(file);
  }
  async function setSlides(entries){
    slides=entries;
    const plates=await Promise.all(entries.map(slide=>Promise.all(slide.items.map(texture))));
    if(disposed)return;
    for(let virtual=-2;virtual<slides.length+3;virtual++){
      const index=(virtual+slides.length)%slides.length;
      const group=new THREE.Group(),theta=virtual*step;
      group.position.set(Math.sin(theta)*4.3,-virtual*pitch,Math.cos(theta)*4.3);group.rotation.y=theta;
      const veil=new THREE.Mesh(veilGeometry,veilMaterial);veil.position.z=-1.1;group.add(veil);
      plates[index].forEach((asset,n)=>{
        const pair=plates[index].length>1;
        const height=Math.min(2.85,(pair?2.18:3.85)/asset.aspect),width=height*asset.aspect;
        const panel=new THREE.Group();panel.position.x=pair?(n===0?-1.25:1.25):0;
        panel.rotation.y=pair?(n===0?.09:-.09):-.12;
        const image=new THREE.Mesh(new THREE.PlaneGeometry(width,height),new THREE.MeshBasicMaterial({map:asset.texture,side:THREE.DoubleSide}));
        panel.add(image);
        const edge=rail(width+.15,height+.15);edge.position.z=-.015;panel.add(edge);
        const glass=new THREE.Mesh(new THREE.PlaneGeometry(width+.2,height+.2),new THREE.MeshPhysicalMaterial({color:0x9486af,metalness:.45,roughness:.18,transparent:true,opacity:.18,side:THREE.DoubleSide}));
        glass.position.z=-.035;panel.add(glass);group.add(panel);
        if(entries[index].items[n].poster)videos.push({index,mesh:image,item:entries[index].items[n],poster:asset.texture,video:null,texture:null});
      });
      panels.push(group);scene.add(group);
      const previous=entries[(index+slides.length-1)%slides.length];
      if(previous.city!==entries[index].city){
        const gate=rail(5.8,4.3);
        const azimuth=(virtual-.5)*step;
        gate.rotation.y=azimuth+Math.PI/2;
        gate.rotation.z=.11;
        gate.position.y=-(virtual-.5)*pitch+1.05;
        const back=rail(5.8,4.3);back.position.z=-.45;gate.add(back);
        scene.add(gate);gates.push({gate,azimuth});
      }
    }
    // Yuvarlak, yumuşak kenarlı nokta dokusu (yıldız ışıkları için).
    const dotCanvas=document.createElement('canvas');dotCanvas.width=dotCanvas.height=64;
    const dc=dotCanvas.getContext('2d'),grad=dc.createRadialGradient(32,32,0,32,32,32);
    grad.addColorStop(0,'rgba(255,255,255,1)');grad.addColorStop(.4,'rgba(255,255,255,.7)');grad.addColorStop(1,'rgba(255,255,255,0)');
    dc.fillStyle=grad;dc.fillRect(0,0,64,64);const dot=new THREE.CanvasTexture(dotCanvas);
    const height=(slides.length+5)*pitch,start=5.7;
    // Ortadaki fırça darbesi girdabı: binlerce kısa, kalın fırça izi Van Gogh'un kıvrımları gibi
    // merkez eksenin etrafında dönerek aşağı akar (fotoğrafların izlediği yolla aynı yönde).
    const strokeCount=window.beoLite?1600:3600,brush=new THREE.InstancedMesh(new THREE.BoxGeometry(.01,.042,.2),new THREE.MeshBasicMaterial({fog:true}),strokeCount);
    const dummy=new THREE.Object3D(),tint=new THREE.Color();
    const palette=[0x1b3a7a,0x2f5fae,0x4f7cc4,0x7aa3e0,0xa9c8f0,0xe8eefc,0xf2c14e,0xe0a030,0xfff1b8];
    for(let i=0;i<strokeCount;i++){
      const band=i%7,y=start-Math.random()*height;
      const a=-y/pitch*step*1.6+band*.9+Math.sin(y*1.3+band)*.35;
      const r=.55+band*.22+.25*Math.sin(y*.9+band*1.7);
      dummy.position.set(Math.sin(a)*r,y,Math.cos(a)*r);
      dummy.lookAt(Math.sin(a+.12)*r,y-.03,Math.cos(a+.12)*r);
      dummy.scale.setScalar(.8+Math.random()*.7);dummy.updateMatrix();brush.setMatrixAt(i,dummy.matrix);
      tint.setHex(band===3?palette[6+Math.floor(Math.random()*3)]:palette[Math.floor(Math.random()*5)]);brush.setColorAt(i,tint);
    }
    shaft.add(brush);
    // Etrafta sarı yıldız ışıkları ve birkaç büyük hale
    const countDust=window.beoLite?700:1400,positions=new Float32Array(countDust*3),colours=new Float32Array(countDust*3);
    const colour=new THREE.Color(),warm=[0xfff1b8,0xf2c14e,0xffe08a,0xe8eefc];
    for(let i=0;i<countDust;i++){
      const y=start-Math.random()*height,a=Math.random()*Math.PI*2,r=2.4+Math.random()*7;
      positions[i*3]=Math.cos(a)*r;positions[i*3+1]=y;positions[i*3+2]=Math.sin(a)*r;
      colour.set(warm[i%warm.length]).toArray(colours,i*3);
    }
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(positions,3));g.setAttribute('color',new THREE.BufferAttribute(colours,3));
    const dust=new THREE.Points(g,new THREE.PointsMaterial({size:.11,map:dot,vertexColors:true,transparent:true,opacity:.8,depthWrite:false,blending:THREE.AdditiveBlending}));shaft.add(dust);
    for(let i=0;i<18;i++){
      const halo=new THREE.Sprite(new THREE.SpriteMaterial({map:dot,color:0xf2c14e,transparent:true,opacity:.35,depthWrite:false,blending:THREE.AdditiveBlending}));
      const a=Math.random()*Math.PI*2,r=3+Math.random()*5;halo.position.set(Math.cos(a)*r,start-Math.random()*height,Math.sin(a)*r);halo.scale.setScalar(.8+Math.random()*1.2);shaft.add(halo);
    }
  }
  function show(index,playing){
    if(active===index)return;
    active=index;const version=++generation;
    for(const entry of videos){
      if(entry.video){entry.video.pause();entry.video.removeAttribute('src');entry.video.load();entry.video=null;}
      if(entry.texture){entry.texture.dispose();entry.texture=null;}entry.mesh.material.map=entry.poster;
    }
    const selected=videos.filter(entry=>entry.index===index);
    if(!selected.length)return;
    // Only the active movie is decoded; repeated helix panels share its texture.
    const video=document.createElement('video');video.src='assets/gallery/'+selected[0].item.src;
    video.muted=video.defaultMuted=true;video.playsInline=true;video.preload='auto';
    selected[0].video=video;
    video.addEventListener('loadeddata',()=>{
      if(disposed||version!==generation)return;
      const map=new THREE.VideoTexture(video);map.colorSpace=THREE.SRGBColorSpace;selected[0].texture=map;
      selected.forEach(entry=>entry.mesh.material.map=map);
      if(playing)video.play().catch(()=>{});
    },{once:true});
  }
  function render(time,position,index,playing,light){
    show(index,playing);
    const theta=position*step,y=-position*pitch;
    const travel=Math.sin(Math.PI*position)**2;
    const halfWidth=2.6;
    const fit=halfWidth/(Math.tan(THREE.MathUtils.degToRad(camera.fov/2))*camera.aspect);
    const radius=4.3+Math.max(5.35,fit)+1.45*travel;
    for(const {gate,azimuth} of gates){
      const crossingRadius=4.3+Math.max(5.35,fit)+1.45;
      gate.position.x=Math.sin(azimuth)*crossingRadius;
      gate.position.z=Math.cos(azimuth)*crossingRadius;
    }
    camera.position.set(Math.sin(theta)*radius,y+1.05,Math.cos(theta)*radius);
    camera.lookAt(Math.sin(theta)*.45,y-.08,Math.cos(theta)*.45);
    shaft.rotation.y=time*.05;veilMaterial.uniforms.clock.value=time;
    key.position.y=y+3;fill.position.y=y-2;gold.position.y=y+1;
    // Arka plan şeffaf: CSS'teki gün batımı degradesi görünür; sis yalnızca uzaktakileri yumuşatır.
    scene.background=null;scene.fog.color.setHex(light?0xc9daf7:0x13285e);
    for(const entry of videos){const video=entry.video;if(!video)continue;if(playing&&video.paused&&!video.ended)video.play().catch(()=>{});else if(!playing&&!video.paused)video.pause();}
    renderer.render(scene,camera);
  }
  const observer=new ResizeObserver(()=>{const w=container.clientWidth,h=container.clientHeight;if(!w||!h)return;paintSky();renderer.setSize(w,h);camera.aspect=w/h;camera.fov=w<700?62:46;camera.updateProjectionMatrix();});observer.observe(container);
  return {setSlides,render,destroy(){disposed=true;sky.remove();removeEventListener('beo-preferences',paintSky);generation++;observer.disconnect();videos.forEach(entry=>{entry.video?.pause();entry.texture?.dispose();});cache.forEach(p=>p.then(asset=>asset.texture.dispose(),()=>{}));scene.traverse(node=>{node.geometry?.dispose();if(Array.isArray(node.material))node.material.forEach(m=>m.dispose());else node.material?.dispose();});renderer.dispose();renderer.domElement.remove();}};
}
