// ---------------------------------------------------------------------------
// tape-room.js — Projeler sayfasındaki kaset odası
// 1) Kasete dokunulur  2) kaset Bip'in yuvasına süzülüp girer
// 3) makaralar döner   4) proje detay penceresi açılır
// "Kaseti çıkar" (veya Esc) ile kaset geri çıkar ve yerine döner.
// Hareket azaltma / hareketi durdur açıksa animasyon atlanır, pencere direkt açılır.
// ---------------------------------------------------------------------------
const stage=document.querySelector('.room-stage');
const dialog=document.querySelector('#tape-dialog');
const status=document.querySelector('#room-status');
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
const still=()=>{const p=window.beoPreferences||{};return p.reduced||p.paused;};
const tr=()=>(window.beoPreferences?.language||'tr')==='tr';

let active=null,flight=null,busy=false;

// Yuvanın sahne içindeki konumu (Bip hafifçe sallandığı için her seferinde ölçülür)
function slotBox(){
  const s=stage.getBoundingClientRect(),r=stage.querySelector('#bip-slot').getBoundingClientRect();
  return {x:r.left-s.left,y:r.top-s.top,w:r.width,h:r.height};
}

async function play(button){
  if(busy)return;busy=true;active=button;
  stage.classList.add('is-busy');button.classList.add('is-inserting');
  const name=button.querySelector('b').textContent;
  status.textContent=tr()?`${name} kaseti takılıyor.`:`Loading the ${name} tape.`;

  if(!still()){
    // Kaset, sol üst köşesi referans alınarak yuvanın tam üstüne taşınır, sonra içeri kayar.
    stage.classList.add('is-receiving');
    const slot=slotBox(),w=button.offsetWidth,h=button.offsetHeight;
    const scale=Math.min(1,slot.w*.92/w);
    const x=slot.x+slot.w/2-(button.offsetLeft+w*scale/2);
    const y=slot.y+slot.h/2-h*scale-button.offsetTop;
    flight=button.animate([
      {transform:'translate(0px,0px) scale(1) rotate(0deg)',clipPath:'inset(0 0 0 0)'},
      {transform:`translate(${x}px,${y-46}px) scale(${scale}) rotate(-7deg)`,clipPath:'inset(0 0 0 0)',offset:.5},
      {transform:`translate(${x}px,${y}px) scale(${scale}) rotate(0deg)`,clipPath:'inset(0 0 0 0)',offset:.7},
      {transform:`translate(${x}px,${y+h*scale}px) scale(${scale}) rotate(0deg)`,clipPath:'inset(0 0 100% 0)'}
    ],{duration:2000,easing:'cubic-bezier(.45,.05,.25,1)',fill:'forwards'});
    await flight.finished.catch(()=>{});
    stage.classList.remove('is-receiving');stage.classList.add('is-playing');
    await wait(700);
  }else{
    button.classList.add('is-hidden');stage.classList.add('is-playing');
  }
  open(button.dataset.tape);
}

function open(id){
  dialog.querySelectorAll('.tape-detail').forEach(article=>{article.hidden=article.dataset.tape!==id;});
  dialog.setAttribute('aria-labelledby','tape-title-'+id);
  dialog.showModal();
}

async function eject(){
  if(!active)return;
  const button=active;
  stage.classList.remove('is-playing');
  if(flight&&!still()){flight.reverse();await flight.finished.catch(()=>{});}
  flight?.cancel();flight=null;
  button.classList.remove('is-inserting','is-hidden');stage.classList.remove('is-busy');
  status.textContent=tr()?'Kaset çıkarıldı.':'Tape ejected.';
  active=null;busy=false;button.focus({preventScroll:true});
}

stage.querySelectorAll('.cassette').forEach(button=>button.addEventListener('click',()=>play(button)));
dialog.querySelector('.tape-eject').addEventListener('click',()=>dialog.close());
// Pencerenin dışına (arka plana) tıklamak da kaseti çıkarır.
dialog.addEventListener('click',event=>{if(event.target===dialog)dialog.close();});
dialog.addEventListener('close',eject);

// Öncesi / sonrası kaydırıcıları: range değeri çizgiyi ve kırpmayı taşır.
dialog.querySelectorAll('[data-ba]').forEach(box=>{
  const range=box.querySelector('.ba-range');
  const set=v=>box.style.setProperty('--pos',v+'%');
  range.addEventListener('input',()=>set(range.value));
  // Fareyle üstünde gezinirken de takip etsin (masaüstü)
  box.addEventListener('pointermove',e=>{if(e.pointerType!=='mouse'||e.buttons)return;const r=box.getBoundingClientRect();const v=Math.round(Math.min(100,Math.max(0,(e.clientX-r.left)/r.width*100)));range.value=v;set(v);});
});
// Berber videosu: pencere açılınca oynasın, kapanınca dursun.
const syncVideo=()=>dialog.querySelectorAll('.tape-video').forEach(v=>{const show=dialog.open&&!v.closest('.tape-detail').hidden;if(show&&!still()){v.preload='auto';v.play().catch(()=>{});}else v.pause();});
new MutationObserver(syncVideo).observe(dialog,{attributes:true,subtree:true,attributeFilter:['open','hidden']});
