import * as THREE from '../vendor/three.module.js';
import {lightRibbon} from './light-ribbon.js';
const background=document.querySelector('#space-background');
const home=document.body.dataset.page==='index';
const canvas=home?background:document.createElement('canvas');
if(!home){
  canvas.className='ribbon-overlay';
  canvas.setAttribute('aria-hidden','true');
  document.body.append(canvas);
}
const prefs=()=>window.beoPreferences||{theme:'dark',paused:false,reduced:false};
start().catch(error=>console.warn('Page lighting unavailable.',error));
async function start(){
  const renderer=new THREE.WebGLRenderer({canvas,alpha:!home,antialias:false,powerPreference:'low-power'});
  renderer.setPixelRatio(window.beoLite?.6:Math.min(devicePixelRatio||1,1.35)); // hafif mod: bulanık arka plan zaten, düşük çözünürlük yeter
  const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
  const uniforms={entrance:{value:document.body.dataset.page==="index"?1:0},resolution:{value:new THREE.Vector2(innerWidth,innerHeight)},light:{value:prefs().theme==='light'?1:0},time:{value:0},zoom:{value:1}};
  const material=new THREE.ShaderMaterial({uniforms,vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:`
    uniform float entrance;uniform vec2 resolution;uniform float light;uniform float time;uniform float zoom;varying vec2 vUv;
    float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
    float noise(vec2 p){vec2 a=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(a),hash(a+vec2(1,0)),f.x),mix(hash(a+vec2(0,1)),hash(a+vec2(1,1)),f.x),f.y);}
    void main(){
      vec2 p=(vUv-.5)/zoom*vec2(resolution.x/resolution.y,1.);
      float haze=noise(p*3.+vec2(time*.018,0.));
      float glow=exp(-length((p-vec2(.12,-.02))*vec2(.85,1.1))*3.4);
      float cobalt=exp(-length((p-vec2(.35,.18))*vec2(1.1,1.8))*4.);
      float violet=exp(-length((p-vec2(-.55,-.32))*vec2(.9,1.8))*3.7);
      vec3 dark=vec3(.007,.009,.025)+vec3(.025,.055,.25)*glow*(.5+haze*.5);
      dark+=vec3(.025,.085,.32)*cobalt+vec3(.09,.025,.16)*violet;
      vec3 pale=vec3(.94,.95,.98)-vec3(.12,.10,.015)*glow*.7;
      // Fan of oblique shafts from one off-screen source.
      vec2 ray=p-vec2(.53,.89);
      float angle=atan(ray.x,-ray.y);
      float drift=.024*sin(time*.13);
      float shafts=.56*exp(-7.*abs(angle+.49+drift))
                  +.36*exp(-25.*abs(angle+.69-drift))
                  +.28*exp(-15.*abs(angle-.12+drift));
      float mist=entrance*shafts*(.46+.54*haze)*(1.-smoothstep(.05,1.65,length(ray)));
      dark+=mix(vec3(.12,.28,.52),vec3(.40,.21,.45),haze)*mist;
      vec2 farRay=p-vec2(.96,.67);
      float farAngle=atan(farRay.x,-farRay.y);
      float silk=.60*exp(-15.*abs(farAngle+.46+drift))
                +.43*exp(-33.*abs(farAngle+.63-drift))
                +.28*exp(-17.*abs(farAngle+.84));
      float outer=entrance*silk*(.42+.58*haze)*exp(-.86*length(farRay));
      dark+=vec3(.23,.38,.67)*outer;
      pale-=vec3(.11,.065,.018)*(mist+outer);
      gl_FragColor=vec4(mix(dark,pale,light),1.);
    }
  `});
  const sky=new THREE.Mesh(new THREE.PlaneGeometry(2,2),material);
  scene.add(sky);
  const ribbon=lightRibbon(scene);
  const backdrop=!home && !['blog','galeri'].includes(document.body.dataset.page)
    ? background.getContext('2d') : null;
  let last=0,dirty=true,trailUntil=0;
  function reset(){
    ribbon.reset();
    trailUntil=0;
    dirty=true;
  }
  function paintBackdrop(){
    if(!home){
      if(backdrop){
        sky.visible=true;
        renderer.render(scene,camera);
        background.width=canvas.width;
        background.height=canvas.height;
        backdrop.drawImage(canvas,0,0);
      }
      sky.visible=false;
      renderer.clear();
    }
  }
  function resize(){
    reset();
    renderer.setSize(innerWidth,innerHeight,false);
    uniforms.resolution.value.set(innerWidth,innerHeight);
    paintBackdrop();
  }
  addEventListener('resize',resize);
  resize();
  addEventListener('beo-preferences',()=>{
    reset();
    uniforms.light.value=prefs().theme==='light'?1:0;
    paintBackdrop();
  });
  // İmleci takip eden ışık şeridi kullanıcı isteğiyle kapatıldı (Kasım 2026).
  addEventListener('pointerout',event=>{if(!event.relatedTarget)reset();});
  addEventListener('pointerdown',reset,{passive:true});
  addEventListener('scroll',reset,{passive:true});
  canvas.dataset.effect='light-ribbon';
  function frame(now){
    requestAnimationFrame(frame);
    if(now-last<33||document.hidden)return;
    last=now;
    if(window.beoChapter)reset();
    if(!prefs().paused&&!prefs().reduced){
      if(trailUntil){
        ribbon.update(now,uniforms.light.value);
        dirty=true;
        if(now>=trailUntil)trailUntil=0;
      }
      if(home&&!window.beoLite){uniforms.time.value=now*.001;dirty=true;}
    }
    uniforms.zoom.value=window.beoChapter?1+window.beoChapter.orbit*.06:1+(window.beoHeroProgress||0)*.13;
    if(dirty){renderer.render(scene,camera);dirty=false;}
  }
  requestAnimationFrame(frame);
}
