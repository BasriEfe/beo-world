import {playFlight} from './chapter-flight.js';
// Sayfadaki ?v= sürümü dinamik yüklenen modüllere de geçer: tarayıcı eski dosyayı göstermesin.
const V=new URL(import.meta.url).search;
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
const read=(key,fallback)=>{try{return localStorage.getItem(key)||fallback;}catch{return fallback;}};
const save=(key,value)=>{try{localStorage.setItem(key,value);}catch{}};
const state={theme:read('beo-world-theme','dark'),language:(()=>{const q=new URLSearchParams(location.search).get('lang');return q==='en'||q==='tr'?q:read('beo-lang','tr');})(),paused:read('beo-world-paused','false')==='true',reduced:reduce.matches};
window.beoPreferences=state;
const announce=()=>window.dispatchEvent(new CustomEvent('beo-preferences',{detail:state}));
function language(lang){
  state.language=lang;document.documentElement.lang=lang;
  document.querySelectorAll('[data-tr][data-en]').forEach(el=>el.innerHTML=el.dataset[lang]);
  document.querySelectorAll('[data-language]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.language===lang)));
  document.title=`${document.body.dataset['title'+(lang==='tr'?'Tr':'En')]} | Basri Efe Özdemir`;
  const meta=document.querySelector('meta[name="description"]');
  if(meta)meta.content=lang==='tr'?document.body.dataset.descTr:document.body.dataset.descEn;
  document.querySelector('.menu-toggle').setAttribute('aria-label',lang==='tr'?'Menüyü aç':'Open menu');
  document.querySelector('.menu-close').setAttribute('aria-label',lang==='tr'?'Menüyü kapat':'Close menu');
  document.querySelector('.profile-photo-toggle')?.setAttribute('aria-label',lang==='tr'?'Fotoğraf ve vesikalık arasında geçiş yap':'Switch between personal photo and portrait');
  save('beo-lang',lang);announce();
}
function appearance(){
  document.documentElement.dataset.theme=state.theme;
  document.documentElement.dataset.motion=state.paused||state.reduced?'paused':'running';
  document.querySelector('meta[name="theme-color"]').content=state.theme==='dark'?'#080b0d':'#f3f4f0';
  document.querySelector('.theme-toggle').setAttribute('aria-label',state.language==='tr'?(state.theme==='dark'?'Açık temaya geç':'Koyu temaya geç'):(state.theme==='dark'?'Switch to light theme':'Switch to dark theme'));
  document.querySelector('.motion-toggle').setAttribute('aria-pressed',String(state.paused));
  document.querySelector('.motion-toggle .fas').className='fas fa-'+(state.paused?'play':'pause');
  document.querySelector('.motion-toggle').setAttribute('aria-label',state.language==='tr'?(state.paused?'Hareketi sürdür':'Hareketi durdur'):(state.paused?'Resume motion':'Pause motion'));
  announce();
}
document.querySelectorAll('[data-language]').forEach(button=>button.addEventListener('click',()=>{language(button.dataset.language);appearance();}));
document.querySelector('.theme-toggle').addEventListener('click',()=>{state.theme=state.theme==='dark'?'light':'dark';save('beo-world-theme',state.theme);appearance();});
document.querySelector('.motion-toggle').addEventListener('click',()=>{state.paused=!state.paused;save('beo-world-paused',String(state.paused));appearance();});
reduce.addEventListener('change',()=>{state.reduced=reduce.matches;announce();});language(state.language);appearance();
const header=document.querySelector('.site-header');
function scrollState(){
  header.classList.toggle('compact',scrollY>35);
  const intro=document.querySelector('.hero-scroll');
  if(!intro||window.beoChapter)return;
  const hero=intro.querySelector('.hero'),rect=intro.getBoundingClientRect();
  const range=Math.max(1,intro.offsetHeight-hero.offsetHeight);
  const start=matchMedia('(max-width:760px)').matches?78:96;
  const progress=state.paused||state.reduced?0:Math.max(0,Math.min(1,(start-rect.top)/range));
  const smooth=progress*progress*(3-2*progress);
  intro.style.setProperty('--journey',smooth);window.beoHeroProgress=smooth;
  document.querySelector('.discover-section')?.style.setProperty('--arrival',Math.min(1,smooth*1.35));
}
addEventListener('scroll',scrollState,{passive:true});scrollState();
addEventListener('resize',scrollState);addEventListener('beo-preferences',scrollState);
const menu=document.querySelector('#site-menu');
const opener=document.querySelector('.menu-toggle');
opener.addEventListener('click',()=>{menu.classList.remove('closing');menu.showModal();document.body.classList.add('menu-open');});
function closeMenu(){
  if(menu.classList.contains('closing'))return;
  menu.classList.add('closing');
  setTimeout(()=>{menu.close();menu.classList.remove('closing');document.body.classList.remove('menu-open');opener.focus({preventScroll:true});},state.reduced?0:320);
}
document.querySelector('.menu-close').addEventListener('click',closeMenu);
menu.addEventListener('click',event=>{
  if(event.target!==menu)return;
  const box=menu.getBoundingClientRect();
  if(event.clientX<box.left||event.clientX>box.right||event.clientY<box.top||event.clientY>box.bottom)closeMenu();
});
menu.addEventListener('cancel',event=>{event.preventDefault();closeMenu();});
const curtain=document.querySelector('.page-transition');
try{if(sessionStorage.getItem('beo-transition')==='1'){sessionStorage.removeItem('beo-transition');curtain.classList.add('reveal');setTimeout(()=>curtain.classList.remove('reveal'),750);}}catch{}
let navigating=false;
document.addEventListener('click',event=>{
  const link=event.target.closest('a[href]');if(!link||event.defaultPrevented||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey||event.button!==0||link.target||link.hasAttribute('download'))return;
  const url=new URL(link.href,location.href);if(url.origin!==location.origin||!url.pathname.endsWith('.html'))return;
  if(url.pathname===location.pathname){if(menu.open){event.preventDefault();closeMenu();}return;}
  if(navigating)return event.preventDefault();
  if(state.reduced)return;
  event.preventDefault();navigating=true;
  if(menu.open){menu.close();document.body.classList.remove('menu-open');}
  curtain.className='page-transition cover';
  try{sessionStorage.setItem('beo-transition','1');}catch{}
  setTimeout(()=>{location.href=url.href;},540);
});
addEventListener('pageshow',event=>{if(event.persisted){navigating=false;curtain.className='page-transition';if(menu.open){menu.close();document.body.classList.remove('menu-open');}}});

// One deliberate scroll gesture completes the entrance chapter transition.
const introChapter=document.querySelector('.hero-scroll');
if(introChapter){
  const categories=document.querySelector('#kesfet');let changing=false,cooldown=0,intent=0,touchY=null;
  const categoryTop=()=>categories.getBoundingClientRect().top+scrollY-(matchMedia('(max-width:760px)').matches?64:72);
  function chapter(direction){
    if(changing||menu.open)return;
    if(state.reduced||state.paused){window.scrollTo({top:direction==='down'?categoryTop():0,behavior:'instant'});return;}
    changing=true;intent=0;document.documentElement.classList.add('chapter-changing');
    introChapter.dataset.transition=direction;
    playFlight({direction,intro:introChapter,categories,onCovered(){window.scrollTo({top:direction==='down'?categoryTop():0,behavior:'instant'});scrollState();},onFinished(){window.scrollTo({top:direction==='down'?categoryTop():0,behavior:'instant'});changing=false;cooldown=performance.now()+450;document.documentElement.classList.remove('chapter-changing');introChapter.dataset.transition='idle';scrollState();}});
  }
  function directionFor(delta){
    if(delta>0&&scrollY<categoryTop()-100)return 'down';
    if(delta<0&&Math.abs(scrollY-categoryTop())<100)return 'up';
    return null;
  }
  addEventListener('wheel',event=>{
    if(state.reduced||state.paused||menu.open||Math.abs(event.deltaX)>Math.abs(event.deltaY)||event.ctrlKey)return;
    if(changing||performance.now()<cooldown){event.preventDefault();return;}
    const direction=directionFor(event.deltaY);if(!direction){intent=0;return;}
    event.preventDefault();intent+=Math.abs(event.deltaY);if(intent>=12)chapter(direction);
  },{passive:false});
  // Dokunmatik ekranlarda (telefon/tablet) kaydırma ele geçirilmez; sayfa doğal kayar.
  const touchOnly=matchMedia('(hover: none)').matches;
  if(!touchOnly)addEventListener('touchstart',event=>{touchY=event.touches.length===1?event.touches[0].clientY:null;},{passive:true});
  if(!touchOnly)addEventListener('touchmove',event=>{
    if(state.reduced||state.paused||menu.open)return;
    if(changing){event.preventDefault();return;}
    if(touchY===null||!event.touches.length)return;
    const delta=touchY-event.touches[0].clientY,direction=directionFor(delta);
    if(direction&&Math.abs(delta)>24){event.preventDefault();touchY=null;if(performance.now()>cooldown)chapter(direction);}
  },{passive:false});
  addEventListener('touchend',()=>touchY=null,{passive:true});
  addEventListener('keydown',event=>{
    if(event.target.closest('button,a,input,textarea,dialog,#world-stage')||event.ctrlKey||event.metaKey||event.altKey)return;
    if(changing){if(['ArrowDown','ArrowUp','PageDown','PageUp',' '].includes(event.key))event.preventDefault();return;}
    const delta=['ArrowDown','PageDown',' '].includes(event.key)?1:['ArrowUp','PageUp'].includes(event.key)?-1:0;
    const direction=directionFor(delta);if(delta&&direction){event.preventDefault();chapter(direction);}
  });
  document.querySelector('.scroll-cue').addEventListener('click',event=>{event.preventDefault();chapter('down');});
}

// A bounded three-copy track wraps visually, without growing the DOM over time.
const viewport=document.querySelector('.category-viewport');
if(viewport)import('./hologram.js'+V).then(({hologram})=>hologram(viewport)).catch(error=>console.warn('Holographic navigation unavailable; links remain available.',error));
const preview=document.querySelector('.certificate-preview');
if(preview){
  const img=preview.querySelector('img'),caption=preview.querySelector('figcaption'),empty=preview.querySelector('.certificate-empty');let pinned=null;
  function show(button){img.src='assets/'+button.dataset.cert;img.alt=button.querySelector('strong').textContent;img.className=button.dataset.kind;img.hidden=false;caption.textContent=button.querySelector('small').textContent;caption.hidden=false;empty.hidden=true;}
  function reset(){if(pinned)return;img.hidden=true;caption.hidden=true;empty.hidden=false;}
  document.querySelectorAll('.certificate-row').forEach(button=>{
    button.addEventListener('pointerenter',()=>show(button));button.addEventListener('focus',()=>show(button));
    button.addEventListener('click',()=>{if(pinned===button){button.setAttribute('aria-pressed','false');pinned=null;reset();return;}document.querySelectorAll('.certificate-row').forEach(b=>b.setAttribute('aria-pressed','false'));pinned=button;button.setAttribute('aria-pressed','true');show(button);});
  });
  document.querySelector('.certificate-list').addEventListener('pointerleave',()=>{if(pinned)show(pinned);else reset();});
  document.querySelector('.certificate-list').addEventListener('focusout',event=>{if(!event.currentTarget.contains(event.relatedTarget)){if(pinned)show(pinned);else reset();}});
}
document.querySelector('#contact-form')?.addEventListener('submit',event=>{
  event.preventDefault();const form=event.currentTarget;if(!form.reportValidity())return;
  const data=new FormData(form),subject=encodeURIComponent(data.get('subject')?`${data.get('subject')} / ${data.get('name')}`:`Website / ${data.get('name')}`),body=encodeURIComponent(`${data.get('message')}\n\n${data.get('name')}\n${data.get('email')}`);
  location.href=`mailto:ozdemirbasriefe@gmail.com?subject=${subject}&body=${body}`;
  document.querySelector('#form-status').textContent=state.language==='tr'?'E-posta uygulaman destekliyorsa taslak açılır. Mesaj henüz gönderilmedi.':'A draft opens if your email app supports it. Your message has not been sent.';
});

const terminal=document.querySelector('.toolkit-terminal');
document.querySelectorAll('[data-photo]').forEach(button=>button.addEventListener('click',()=>{
  const photo=document.querySelector('.profile-photo');if(!photo||button.getAttribute('aria-pressed')==='true')return;
  document.querySelectorAll('[data-photo]').forEach(item=>item.setAttribute('aria-pressed',String(item===button)));
  photo.src='assets/'+button.dataset.photo;photo.classList.toggle('is-personal',button.dataset.photo==='personal-photo.jpg');
}));
document.querySelector('.profile-photo-toggle')?.addEventListener('click',()=>document.querySelector('[data-photo][aria-pressed="false"]')?.click());
if(terminal){
  const code=terminal.querySelector('.toolkit-code'),result=terminal.querySelector('.toolkit-result');
  let visible=false,started=0,index=-1,outputAt=0,lastLanguage=state.language;
  const sentence=()=>`Console.WriteLine("${state.language==='tr'?'Öğrendiklerim.':'What I’m learning.'}");`;
  function reset(){started=0;index=-1;outputAt=0;code.textContent='';terminal.classList.remove('has-output');}
  new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;},{threshold:.35}).observe(terminal);
  addEventListener('beo-preferences',()=>{if(lastLanguage!==state.language){lastLanguage=state.language;reset();}});
  function type(now){
    requestAnimationFrame(type);if(!visible||document.hidden){started=0;return;}
    if(state.reduced||state.paused){code.textContent=sentence();terminal.classList.add('has-output');return;}
    if(!started)started=now;
    if(outputAt){if(now-outputAt>7000)reset();return;}
    const text=sentence(),n=Math.min(text.length,Math.floor((now-started)/58));
    if(n!==index){index=n;code.textContent=text.slice(0,n);terminal.dataset.typed=String(n);}
    if(n===text.length&&now-started>text.length*58+300){terminal.classList.add('has-output');outputAt=now;}
  }reset();requestAnimationFrame(type);
}

import('./page-light.js'+V).catch(error=>console.warn('Background unavailable.',error));
import('./scene.js'+V).catch(()=>{document.querySelector('#world-stage')?.classList.add('fallback-mode');});
if(document.querySelector('.hobbies-grid'))import('./hobby-icons.js'+V).catch(error=>console.warn('Interest icons unavailable.',error));
if(document.querySelector('.journal-archive'))import('./journal.js'+V).catch(error=>console.warn('Journal interactions unavailable.',error));
if(document.querySelector('#journey-map'))import('./journey-map.js'+V).catch(error=>console.warn('Journey map unavailable.',error));
if(document.querySelector('.gallery-film'))import('./gallery-film.js'+V).catch(error=>{console.warn('Gallery tour unavailable.',error);document.querySelector('.film-status').textContent=state.language==='tr'?'Galeri yüklenemedi. Sayfayı yenileyebilirsin.':'Gallery could not load. Please reload.';});

// Kaydırma ilerleme çizgisi (üstte ince ışık)
{const bar=document.querySelector('.scroll-progress span');if(bar){let raf=0;const upd=()=>{raf=0;const h=document.documentElement.scrollHeight-innerHeight;bar.style.transform=`scaleX(${h>0?Math.min(1,scrollY/h):0})`;};addEventListener('scroll',()=>{if(!raf)raf=requestAnimationFrame(upd);},{passive:true});addEventListener('resize',upd);upd();}}
// Konsola küçük bir selam
console.log('%cBEO%c\nMerhaba! Bu siteyi Basri Efe Özdemir hazırladı.\nWeb Tasarımının Temelleri · Akdeniz Üniversitesi · 2026','font:700 42px Impact,sans-serif;color:#a78bff;letter-spacing:4px','font:13px system-ui;color:#8e8bbd');
