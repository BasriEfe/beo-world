import * as THREE from '../vendor/three.module.js';

export function createAircraft(){
  const group=new THREE.Group(),fans=[];
  const white=new THREE.MeshPhysicalMaterial({color:0xe8ebe8,metalness:.28,roughness:.3,clearcoat:.6});
  const metal=new THREE.MeshStandardMaterial({color:0xaab6b7,metalness:.78,roughness:.3});
  const dark=new THREE.MeshStandardMaterial({color:0x263638,metalness:.45,roughness:.3});
  const glass=new THREE.MeshPhysicalMaterial({color:0x111d24,metalness:.5,roughness:.16,clearcoat:1});
  const add=(geometry,material,parent=group,x=0,y=0,z=0)=>{const object=new THREE.Mesh(geometry,material);object.position.set(x,y,z);parent.add(object);return object;};
  const profile=[[0,-1.68],[.035,-1.56],[.09,-1.34],[.145,-1.08],[.158,-.86],[.158,.95],[.145,1.18],[.115,1.39],[.055,1.59],[0,1.69]];
  const body=add(new THREE.LatheGeometry(profile.map(p=>new THREE.Vector2(...p)),64),white);body.rotation.z=-Math.PI/2;
  function foil(side,span,rootLead,rootTrail,tipLead,tipTrail,y){
    const vertices=[],indices=[],spanSteps=14,chordSteps=12;
    for(let surface=0;surface<2;surface++)for(let j=0;j<=spanSteps;j++)for(let i=0;i<=chordSteps;i++){
      const s=j/spanSteps,c=i/chordSteps,leading=THREE.MathUtils.lerp(rootLead,tipLead,s),trailing=THREE.MathUtils.lerp(rootTrail,tipTrail,s);
      vertices.push(THREE.MathUtils.lerp(leading,trailing,c),y+s*.075+Math.sin(c*Math.PI)*(.038*(1-s*.6))*(surface===0?1:-.45),side*(.06+s*span));
    }
    const plane=(spanSteps+1)*(chordSteps+1);
    for(let surface=0;surface<2;surface++)for(let j=0;j<spanSteps;j++)for(let i=0;i<chordSteps;i++){
      const a=surface*plane+j*(chordSteps+1)+i,b=a+chordSteps+1;
      indices.push(a,b,a+1,a+1,b,b+1);
    }
    const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geometry.setIndex(indices);geometry.computeVertexNormals();
    const material=metal.clone();material.side=THREE.DoubleSide;add(geometry,material);
  }
  function fin(points,z,material){
    const shape=new THREE.Shape();points.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
    return add(new THREE.ExtrudeGeometry(shape,{depth:.025,bevelEnabled:true,bevelSize:.012,bevelThickness:.008,bevelSegments:2}),material,group,0,0,z-.0125);
  }
  fin([[-1.5,.03],[-1.53,.66],[-1.32,.68],[-.91,.03]],0,dark);
  for(const side of [-1,1]){
    foil(side,1.46,.42,-.6,-.55,-.82,-.025);
    foil(side,.57,-1.01,-1.48,-1.47,-1.68,.045);
    fin([[-.82,.045],[-.83,.31],[-.72,.34],[-.55,.055]],side*1.52,dark);
    const engine=new THREE.Group();engine.position.set(.17,-.22,side*.64);group.add(engine);
    const shell=add(new THREE.LatheGeometry([[.083,-.25],[.102,-.17],[.115,.15],[.112,.24],[.086,.245],[.083,.15]].map(p=>new THREE.Vector2(...p)),40),white,engine);shell.rotation.z=-Math.PI/2;
    const inlet=add(new THREE.CircleGeometry(.084,32),dark,engine,.246);inlet.rotation.y=Math.PI/2;
    const fan=new THREE.Group();fan.position.x=.25;engine.add(fan);fans.push(fan);
    const hub=add(new THREE.ConeGeometry(.027,.058,24),metal,fan,.015);hub.rotation.z=-Math.PI/2;
    for(let i=0;i<16;i++){
      const angle=i/16*Math.PI*2,points=[0,Math.cos(angle)*.025,Math.sin(angle)*.025,0,Math.cos(angle+.12)*.077,Math.sin(angle+.12)*.077,.003,Math.cos(angle+.34)*.073,Math.sin(angle+.34)*.073];
      const blade=new THREE.BufferGeometry();blade.setAttribute('position',new THREE.Float32BufferAttribute(points,3));blade.computeVertexNormals();
      const material=metal.clone();material.side=THREE.DoubleSide;add(blade,material,fan);
    }
    add(new THREE.BoxGeometry(.2,.18,.045),metal,group,.07,-.11,side*.64);
    for(let i=0;i<16;i++){
      const window=add(new THREE.SphereGeometry(.022,12,8),glass,group,.93-i*.116,.055,side*.147);window.scale.set(.73,1,.18);
    }
    const windscreen=[1.13,.125,side*.069,1.36,.082,side*.067,1.4,.047,side*.105,1.17,.087,side*.133];
    const glazing=new THREE.BufferGeometry();glazing.setAttribute('position',new THREE.Float32BufferAttribute(windscreen,3));glazing.setIndex([0,1,2,0,2,3]);glazing.computeVertexNormals();
    const cockpit=glass.clone();cockpit.side=THREE.DoubleSide;add(glazing,cockpit);
    for(const x of [-1.03,1.02]){
      const door=[new THREE.Vector3(x-.045,-.073,side*.15),new THREE.Vector3(x-.045,.088,side*.132),new THREE.Vector3(x+.045,.088,side*.132),new THREE.Vector3(x+.045,-.073,side*.15)];
      group.add(new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(door),new THREE.LineBasicMaterial({color:0x7b898a})));
    }
    const lamp=new THREE.MeshStandardMaterial({color:side<0?0xb15b58:0x699b88,emissive:side<0?0xb15b58:0x699b88,emissiveIntensity:.5});
    add(new THREE.SphereGeometry(.017,12,8),lamp,group,-.69,.09,side*1.52);
  }
  return {group,update:(time,energy)=>{group.rotation.x=Math.sin(time*.75)*(.025+energy*.12);group.rotation.z=Math.sin(time*.55)*(.018+energy*.055);fans.forEach(fan=>fan.rotation.x=time*(1+energy*4));}};
}

let thumbnail;
export function aircraftThumbnail(){
  if(thumbnail)return thumbnail;
  const renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true});renderer.setSize(192,192);renderer.setPixelRatio(1);renderer.setClearColor(0,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
  const scene=new THREE.Scene(),camera=new THREE.OrthographicCamera(-1.95,1.95,1.95,-1.95,.1,20);camera.position.set(0,6,0);camera.up.set(0,0,-1);camera.lookAt(0,0,0);
  const aircraft=createAircraft();scene.add(aircraft.group,new THREE.HemisphereLight(0xffffff,0x526265,2.4));
  const key=new THREE.DirectionalLight(0xffffff,3);key.position.set(3,6,-3);scene.add(key);renderer.render(scene,camera);thumbnail=renderer.domElement.toDataURL('image/png');
  const geometries=new Set(),materials=new Set();scene.traverse(object=>{if(object.geometry)geometries.add(object.geometry);if(object.material)materials.add(object.material);});
  geometries.forEach(g=>g.dispose());materials.forEach(m=>m.dispose());renderer.dispose();renderer.forceContextLoss();return thumbnail;
}
