import * as THREE from '../vendor/three.module.js';
import {createAircraft} from './aircraft.js';

const mat=(color,metalness=.1,roughness=.45)=>new THREE.MeshStandardMaterial({color,metalness,roughness});
const mesh=(geometry,material,parent,x=0,y=0,z=0)=>{const m=new THREE.Mesh(geometry,material);m.position.set(x,y,z);parent.add(m);return m;};
const box=(parent,w,h,d,material,x=0,y=0,z=0)=>mesh(new THREE.BoxGeometry(w,h,d),material,parent,x,y,z);
function rod(parent,a,b,r,material){const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b),delta=end.clone().sub(start);const m=mesh(new THREE.CylinderGeometry(r,r,delta.length(),12),material,parent);m.position.copy(start.add(end).multiplyScalar(.5));m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),delta.normalize());return m;}
function lathe(parent,points,material){return mesh(new THREE.LatheGeometry(points.map(([x,y])=>new THREE.Vector2(x,y)),64),material,parent);}
function line(parent,points,material,r=.012){return mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p))),64,r,8,false),material,parent);}

export function createInterestObject(kind){
  const group=new THREE.Group(),silver=mat(0xa1afad,.78,.28),dark=mat(0x1e292a,.45,.3),paper=mat(0xe2dfd4,0,.75);
  let update=()=>{};
  if(kind==='chess'){
    lathe(group,[[0,-1],[.57,-1],[.59,-.92],[.56,-.8],[.44,-.75],[.44,-.65],[.32,-.58],[.27,-.35],[.26,-.22],[0,-.22]],silver);
    const shape=new THREE.Shape();shape.moveTo(-.35,-.25);shape.bezierCurveTo(-.38,.18,-.28,.55,-.02,.85);shape.lineTo(-.03,1.15);shape.lineTo(.17,1.01);shape.lineTo(.29,1.08);shape.lineTo(.36,.83);shape.bezierCurveTo(.5,.67,.66,.45,.68,.3);shape.lineTo(.59,.14);shape.lineTo(.3,.18);shape.lineTo(.12,.4);shape.bezierCurveTo(.08,.1,.25,-.05,.35,-.25);shape.closePath();
    const head=mesh(new THREE.ExtrudeGeometry(shape,{depth:.32,bevelEnabled:true,bevelSize:.065,bevelThickness:.07,bevelSegments:4,steps:1,curveSegments:32}),silver,group,0,0,-.16);
    for(const z of [-.232,.232]){mesh(new THREE.SphereGeometry(.038,16,12),dark,group,.25,.73,z);}
    for(let i=0;i<7;i++)line(group,[[-.3+i*.03,-.03+i*.11,.24],[-.22+i*.025,.01+i*.11,.25]],dark,.014);
    group.rotation.set(.05,-.45,-.06);
    update=(t,energy)=>{head.rotation.z=Math.sin(t*1.3)*.018*energy;};
  }else if(kind==='language'){
    const flagCanvas=document.createElement('canvas');flagCanvas.width=600;flagCanvas.height=360;const c=flagCanvas.getContext('2d');c.fillStyle='#12254c';c.fillRect(0,0,600,360);
    const stripe=(x1,y1,x2,y2,width,color)=>{c.strokeStyle=color;c.lineWidth=width;c.beginPath();c.moveTo(x1,y1);c.lineTo(x2,y2);c.stroke();};
    stripe(0,0,600,360,72,'#f5f2e9');stripe(600,0,0,360,72,'#f5f2e9');stripe(0,0,600,360,26,'#b82d3f');stripe(600,0,0,360,26,'#b82d3f');stripe(300,0,300,360,118,'#f5f2e9');stripe(0,180,600,180,112,'#f5f2e9');stripe(300,0,300,360,66,'#b82d3f');stripe(0,180,600,180,62,'#b82d3f');
    const texture=new THREE.CanvasTexture(flagCanvas);texture.colorSpace=THREE.SRGBColorSpace;
    rod(group,[-1,-1.15,0],[-1,1.25,0],.035,silver);mesh(new THREE.SphereGeometry(.065,20,16),silver,group,-1,1.25,0);
    lathe(group,[[0,-1.18],[.3,-1.18],[.3,-1.12],[.07,-1.08],[0,-1.08]],dark).position.x=-1;
    const geo=new THREE.PlaneGeometry(1.95,1.17,40,24);geo.translate(0,.55,0);
    const flag=mesh(geo,new THREE.MeshStandardMaterial({map:texture,side:THREE.DoubleSide,roughness:.85}),group,0,0,0);
    const original=geo.attributes.position.array.slice();
    update=(t,energy)=>{const p=geo.attributes.position;for(let i=0;i<p.count;i++){const x=original[i*3],y=original[i*3+1],weight=(x+.975)/1.95;p.setZ(i,Math.sin(x*3.8-t*(2+energy))*weight*.15+Math.sin(y*5+x*3-t*2)*weight*.045);}p.needsUpdate=true;geo.computeVertexNormals();};
    group.rotation.set(-.06,-.28,0);
  }else if(kind==='sport'){
    const bag=new THREE.Group();group.add(bag);bag.position.y=.9;
    const leather=mat(0x354247,.05,.7),stitch=mat(0x889492,.1,.75);
    const bagBody=lathe(bag,[[0,-1.95],[.32,-1.95],[.44,-1.84],[.47,-1.65],[.47,-.45],[.43,-.3],[.31,-.24],[0,-.24]],leather);
    for(const y of [-1.78,-.43]){const ring=mesh(new THREE.TorusGeometry(.455,.013,8,64),stitch,bag,0,y,0);ring.rotation.x=Math.PI/2;}
    for(let j=0;j<28;j++){const y=-1.7+j*.044;rod(bag,[.14,y,.448],[.18,y+.02,.448],.006,stitch);}
    box(bag,.34,.19,.02,dark,0,-.63,.469);
    for(const a of [0,Math.PI*2/3,Math.PI*4/3]){
      const x=Math.cos(a)*.3,z=Math.sin(a)*.3;
      for(let i=0;i<10;i++){const f=i/10;const ring=mesh(new THREE.TorusGeometry(.035,.009,6,12),silver,bag,x*(1-f),-.26+f*.59,z*(1-f));ring.rotation.y=i%2?Math.PI/2:0;}
    }
    update=(t,energy)=>{bag.rotation.z=Math.sin(t*2.7)*(.025+energy*.19);bag.rotation.x=Math.sin(t*2.4)*.025;bagBody.rotation.y=Math.sin(t*.25)*.03;};
  }else if(kind==='music'){
    const wood=mat(0x795b40,.05,.36),edge=mat(0x3d3026,.1,.35),string=mat(0xd9d5c6,.9,.2);
    const body=new THREE.Shape();body.moveTo(0,-1);body.bezierCurveTo(-.78,-1,-.8,-.3,-.3,-.15);body.bezierCurveTo(-.16,-.02,-.2,.08,-.43,.17);body.bezierCurveTo(-.67,.5,-.39,.77,0,.77);body.bezierCurveTo(.39,.77,.67,.5,.43,.17);body.bezierCurveTo(.2,.08,.16,-.02,.3,-.15);body.bezierCurveTo(.8,-.3,.78,-1,0,-1);
    const geo=new THREE.ExtrudeGeometry(body,{depth:.16,bevelEnabled:true,bevelSegments:4,bevelSize:.055,bevelThickness:.05,curveSegments:32});mesh(geo,wood,group,0,0,-.08);
    box(group,.15,.85,.12,edge,0,1.04,.01);box(group,.11,1.5,.035,dark,0,.43,.17);
    for(const x of [-.25,.25])line(group,[[x,.42,.19],[x-.07,.27,.2],[x,.09,.2],[x+.04,-.15,.2],[x-.02,-.34,.19]],edge,.024);
    box(group,.25,.07,.09,paper,0,-.35,.25);box(group,.2,.32,.06,dark,0,-.77,.22);
    for(const x of [-.044,-.015,.015,.044])rod(group,[x,-.87,.3],[x,1.45,.2],.0035,string);
    mesh(new THREE.TorusGeometry(.09,.035,12,28),wood,group,0,1.54,.02);
    for(const y of [1.24,1.4])rod(group,[-.19,y,.01],[.19,y,.01],.035,edge);
    const bow=new THREE.Group();group.add(bow);rod(bow,[-.9,-.35,.34],[1,.3,.34],.014,wood);rod(bow,[-.9,-.42,.34],[1,.23,.34],.004,paper);
    update=(t,energy)=>{bow.position.x=Math.sin(t*3)*energy*.36;bow.position.y=Math.sin(t*3)*energy*.1;};
    group.scale.setScalar(.83);group.rotation.set(.08,-.25,-.22);
  }else if(kind==='thought'){
    const volume=new THREE.Group();group.add(volume);volume.position.set(0,-.88,0);volume.scale.setScalar(.64);volume.rotation.x=-.8;
    const left=new THREE.Group(),right=new THREE.Group();volume.add(left,right);left.rotation.y=-.22;right.rotation.y=.22;
    for(const [half,side] of [[left,-1],[right,1]]){
      box(half,.94,1.43,.08,dark,side*.49,0,-.07);box(half,.88,1.35,.12,paper,side*.48,0,.01);
      for(let i=0;i<11;i++)box(half,.64,.012,.003,silver,side*.48,.52-i*.09,.075);
    }
    rod(volume,[0,-.72,.08],[0,.72,.08],.024,silver);
    const cross=new THREE.Group();group.add(cross);cross.position.set(0,.18,.12);
    const contour=new THREE.Shape();contour.moveTo(-.09,-.95);for(const [x,y] of [[.09,-.95],[.09,.34],[.56,.34],[.56,.53],[.09,.53],[.09,1],[-.09,1],[-.09,.53],[-.56,.53],[-.56,.34],[-.09,.34]])contour.lineTo(x,y);contour.closePath();
    mesh(new THREE.ExtrudeGeometry(contour,{depth:.09,bevelEnabled:true,bevelSize:.022,bevelThickness:.018,bevelSegments:4}),silver,cross);
    rod(cross,[0,-.84,.115],[0,.89,.115],.008,dark);rod(cross,[-.46,.435,.115],[.46,.435,.115],.008,dark);
    update=(t,energy)=>{right.rotation.y=.22+Math.sin(t*1.2)*energy*.28;cross.rotation.y=Math.sin(t*.7)*.07;};
    group.rotation.set(.02,-.25,-.04);
  }else if(kind==='travel'){
    const aircraft=createAircraft();group.add(aircraft.group);group.rotation.set(.3,-.48,.09);group.scale.setScalar(1.06);update=aircraft.update;
  }else if(kind==='home'){
    const stone=mat(0xd4d9d3,.1,.65),glass=mat(0x263c41,.55,.18);
    box(group,2.05,.12,1.8,silver,0,-.88,0);box(group,1.63,1.32,1.38,stone,0,-.16,0);
    const roof=new THREE.Shape();roof.moveTo(-1,.5);roof.lineTo(0,1.12);roof.lineTo(1,.5);roof.closePath();
    mesh(new THREE.ExtrudeGeometry(roof,{depth:1.62,bevelEnabled:true,bevelSize:.025,bevelThickness:.02,bevelSegments:2}),dark,group,0,0,-.81);
    box(group,.35,.84,.035,glass,.35,-.35,.705);box(group,.58,.5,.035,glass,-.38,.07,.705);
    box(group,.025,.5,.015,silver,-.38,.07,.73);box(group,.58,.025,.015,silver,-.38,.07,.73);
    box(group,.6,.07,.36,silver,.35,-.78,.84);mesh(new THREE.SphereGeometry(.02,12,8),paper,group,.46,-.35,.735);
    group.rotation.set(.12,-.52,0);group.scale.setScalar(.86);
  }else if(kind==='space'){
    const sun=mesh(new THREE.SphereGeometry(.29,48,32),mat(0xc6b38b,.25,.5),group);const planets=[];
    for(let i=0;i<5;i++){
      const radius=.55+i*.22;const path=[];for(let j=0;j<=100;j++){const a=j/100*Math.PI*2;path.push(new THREE.Vector3(Math.cos(a)*radius,0,Math.sin(a)*radius));}
      const orbit=new THREE.Line(new THREE.BufferGeometry().setFromPoints(path),new THREE.LineBasicMaterial({color:0x647574,transparent:true,opacity:.4}));group.add(orbit);
      planets.push({mesh:mesh(new THREE.SphereGeometry([.055,.08,.095,.07,.17][i],32,24),mat([0x8d8175,0xac9f83,0x6c999e,0x956f59,0xa99b84][i],.15,.55),group),radius,speed:.5/(i*.6+1),phase:i*1.8});
    }
    group.rotation.set(.5,.1,.13);
    update=(t,energy)=>{for(const p of planets){const a=t*p.speed+p.phase+energy*.4;p.mesh.position.set(Math.cos(a)*p.radius,0,Math.sin(a)*p.radius);p.mesh.rotation.y=t*.2;}sun.rotation.y=t*.08;};
  }
  return {group,update};
}
