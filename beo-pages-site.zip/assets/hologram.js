import * as THREE from '../vendor/three.module.js';
import {createRoom} from './category-room.js';
export async function hologram(viewport){
  const links=[...viewport.querySelectorAll('.category-set:nth-child(2)>.category')].slice(0,6);
  const preferences=()=>window.beoPreferences||{language:'en',paused:false,reduced:false,theme:'dark'};
  await document.fonts.ready;
  const canvas=document.createElement('canvas');canvas.className='hologram-canvas';canvas.setAttribute('aria-hidden','true');
  viewport.append(canvas);
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true,powerPreference:'low-power'});
  renderer.setPixelRatio(Math.min(devicePixelRatio,window.beoLite?1.2:1.7));renderer.outputColorSpace=THREE.SRGBColorSpace;
  const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(72,1,.1,70);
  camera.position.set(0,.15,.25);camera.lookAt(0,.05,-6);
  const ring=new THREE.Group();scene.add(ring);
  const radius=8.05,count=12,angleStep=Math.PI*2/count;
  const textures=[];
  await import("./scene.js");
  const models=links.map(link=>link.querySelector('[data-object] img'));
  await Promise.all(models.map(model=>model?.decode().catch(()=>{})));
  function ink(index){
    const plate=document.createElement('canvas');plate.width=768;plate.height=1000;
    const c=plate.getContext('2d');
    const glow=c.createLinearGradient(0,0,768,1000);glow.addColorStop(0,'rgba(12,41,54,.68)');glow.addColorStop(.5,'rgba(11,43,55,.32)');glow.addColorStop(1,'rgba(6,23,36,.76)');
    c.fillStyle=glow;c.fillRect(0,0,768,1000);
    c.strokeStyle='#c4cca192';c.lineWidth=1.8;c.strokeRect(2,2,764,996);
    c.strokeStyle='#c8d2b346';c.strokeRect(18,18,732,964);
    c.strokeStyle='#e9d9ac';c.lineWidth=3;
    for(const [x,y,s] of [[30,30,1],[738,970,-1]]){c.beginPath();c.moveTo(x,y+38*s);c.lineTo(x,y);c.lineTo(x+38*s,y);c.stroke();}
    c.fillStyle='#a2d7e5';c.font='18px Body';c.fillText(String(index+1).padStart(2,'0'),58,87);
    const title=links[index].querySelector('.category-heading h2').textContent.toLocaleUpperCase(preferences().language);
    c.fillStyle='#fff7de';c.font='500 53px Body';c.fillText(title,58,180,650);
    c.save();
    c.translate(384,480);
    const accent=c.createLinearGradient(-110,-95,90,100);
    accent.addColorStop(0,'#fff0c1');accent.addColorStop(.45,'#a0e7e4');accent.addColorStop(1,'#718eba');
    c.strokeStyle=accent;c.lineWidth=5;c.lineCap='round';c.lineJoin='round';
    c.shadowColor='#65bfcf';c.shadowBlur=9;
    const symbols=[
      'M-88 12L0 -67L88 12 M-64 -3V75H-15V29H19V75H65V-3',
      'M-97 -20L0 -64L97 -20L0 24Z M-61 1V44Q0 87 61 44V1 M92 -17V46',
      'M-51 -48L-97 0L-51 48 M52 -48L98 0L52 48 M22 -68L-22 68',
      'M-92 -40H-46L-28 -65H29L47 -40H92V66H-92Z M41 8A41 41 0 1 1 -41 8A41 41 0 1 1 41 8Z M65 -21H74',
      'M0 -43Q-46 -71 -94 -53V60Q-45 43 0 72Q45 43 94 60V-53Q46 -71 0 -43V72 M-71 -26Q-43 -32 -22 -18 M22 -18Q43 -32 71 -26',
      'M-95 -58L96 -58V63H-95Z M-93 -55L0 17L94 -55 M-91 60L-28 1 M91 60L28 1'
    ];
    const model=models[index];
    if(model?.naturalWidth){
      c.shadowBlur=14;c.drawImage(model,-208,-208,416,416);
    }else{
    const emblem=new Path2D(symbols[index]);
    c.fillStyle='rgba(84,150,180,.12)';c.fill(emblem);
    c.save();c.translate(3,5);c.lineWidth=8;c.strokeStyle='#24374c';c.stroke(emblem);c.restore();
    c.stroke(emblem);
    }
    c.shadowBlur=0;c.lineWidth=1.5;c.strokeStyle='#e8dba4aa';
    c.beginPath();c.ellipse(0,3,134,115,-.23,.22,2.55);c.stroke();
    c.beginPath();c.ellipse(0,3,134,115,-.23,3.35,5.6);c.stroke();
    c.restore();
    c.strokeStyle='#8dc3ce44';c.lineWidth=1;c.beginPath();c.moveTo(58,738);c.lineTo(710,738);c.stroke();
    c.fillStyle='#afc9d2';c.font='25px Body';c.textAlign='left';
    const words=links[index].querySelector('p').textContent.split(' ');let line='',y=810;
    for(const word of words){if(c.measureText(line+word).width>630){c.fillText(line,58,y);y+=38;line='';}line+=word+' ';}c.fillText(line,58,y);
    c.fillStyle='#c1d2d3';c.font='18px Body';c.fillText('BEO / '+String(index+1).padStart(2,'0'),58,944);
    const texture=new THREE.CanvasTexture(plate);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(renderer.capabilities.getMaxAnisotropy(),8);return texture;
  }
  for(let i=0;i<6;i++)textures.push(ink(i));
  // Each sample carries its panel UV so that the particles inherit the printed symbol.
  const grainGeometry=new THREE.BufferGeometry();
  const samples=3600,grainPositions=[],grainUvs=[];
  for(let i=0;i<samples;i++){
    const u=Math.random(),v=Math.random();
    grainPositions.push((u-.5)*2.9,(v-.5)*4.25,Math.random()*.05);
    grainUvs.push(u,v);
  }
  grainGeometry.setAttribute('position',new THREE.Float32BufferAttribute(grainPositions,3));
  grainGeometry.setAttribute('uv',new THREE.Float32BufferAttribute(grainUvs,2));
  const cards=[];
  for(let i=0;i<count;i++){
    const angle=i*angleStep;
    const panelGeometry=new THREE.PlaneGeometry(2.9,4.25,24,1);
    const surface=panelGeometry.getAttribute('position');
    for(let v=0;v<surface.count;v++){
      const x=surface.getX(v);
      surface.setZ(v,.085*x*x);
    }
    const card=new THREE.Mesh(panelGeometry,new THREE.MeshBasicMaterial({map:textures[i%6],transparent:true,side:THREE.DoubleSide,depthWrite:false}));
    card.position.set(Math.sin(angle)*radius,0,-Math.cos(angle)*radius);card.rotation.y=-angle;card.userData.link=i%6;ring.add(card);cards.push(card);
    const scattering=new THREE.ShaderMaterial({
      transparent:true,depthWrite:false,blending:THREE.AdditiveBlending,
      uniforms:{map:{value:textures[i%6]},spread:{value:0},pixelRatio:{value:renderer.getPixelRatio()}},
      vertexShader:`varying vec2 sampleUv;uniform float spread,pixelRatio;
        void main(){sampleUv=uv;vec3 p=position;
        p.x+=spread*(.42*sin(21.*uv.y+uv.x*5.)+.15*cos(uv.y*44.));
        p.y+=spread*.33*sin(uv.x*28.+uv.y*11.);p.z+=spread*(.2+position.z*12.);
        vec4 view=modelViewMatrix*vec4(p,1.);gl_Position=projectionMatrix*view;
        gl_PointSize=clamp(15./(-view.z),1.,3.)*pixelRatio;}`,
      fragmentShader:`uniform float spread;uniform sampler2D map;varying vec2 sampleUv;
        void main(){vec4 ink=texture2D(map,sampleUv);float dotAlpha=1.-smoothstep(.12,.5,length(gl_PointCoord-.5));
        gl_FragColor=vec4(mix(vec3(.23,.71,.9),ink.rgb,.65),spread*dotAlpha*(.24+ink.a*.72));}`
    });
    const fragments=new THREE.Points(grainGeometry,scattering);card.add(fragments);
    card.userData.scattering=scattering;
    const frame=new THREE.EdgesGeometry(new THREE.BoxGeometry(3.06,4.42,.12));
    const frameLines=new THREE.LineSegments(frame,new THREE.LineBasicMaterial({
      color:0xc6bb90,transparent:true,opacity:.52
    }));
    frameLines.position.z=-.13;
    card.add(frameLines);
    const glass=new THREE.Mesh(new THREE.PlaneGeometry(3.06,4.42),
      new THREE.ShaderMaterial({
        transparent:true,depthWrite:false,
        vertexShader:`varying vec2 uvGlass;varying vec3 viewRay;varying vec3 faceNormal;
          void main(){uvGlass=uv;vec4 point=modelViewMatrix*vec4(position,1.);
          viewRay=-point.xyz;faceNormal=normalMatrix*normal;gl_Position=projectionMatrix*point;}`,
        fragmentShader:`varying vec2 uvGlass;varying vec3 viewRay;varying vec3 faceNormal;
          void main(){float facing=abs(dot(normalize(faceNormal),normalize(viewRay)));
          float sheen=exp(-14.*abs(uvGlass.x+.32*uvGlass.y-facing));
          gl_FragColor=vec4(.27,.57,.87,.055+.14*sheen+.13*pow(1.-facing,2.));}`
      }));
    glass.position.z=-.18;
    card.add(glass);
    const reflection=new THREE.Mesh(card.geometry,new THREE.ShaderMaterial({uniforms:{map:{value:textures[i%6]}},transparent:true,depthWrite:false,side:THREE.DoubleSide,
      vertexShader:'varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader:'uniform sampler2D map;varying vec2 vUv;void main(){vec4 c=texture2D(map,vec2(vUv.x,1.-vUv.y));gl_FragColor=vec4(c.rgb,c.a*pow(vUv.y,3.)*.23);}'
    }));
    reflection.position.copy(card.position);reflection.position.y=-5.2;reflection.rotation.y=card.rotation.y;ring.add(reflection);
  }
  createRoom(scene);
  const gaze=new THREE.Vector2(),eye=new THREE.Vector2();
  canvas.addEventListener('pointerleave',()=>gaze.set(0,0));
  const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
  let offset=0,target=0,down=null,last=0,idleUntil=0,visible=false,movedAt=-1000;
  function rebuild(){
    textures.forEach(texture=>texture.dispose());for(let i=0;i<6;i++)textures[i]=ink(i);
    cards.forEach((card,i)=>{card.material.map=textures[i%6];card.userData.scattering.uniforms.map.value=textures[i%6];});
    ring.children.filter(node=>node.material?.uniforms?.map).forEach((node,i)=>node.material.uniforms.map.value=textures[i%6]);
  }
  addEventListener('beo-preferences',rebuild);
  new IntersectionObserver(entries=>visible=entries[0].isIntersecting).observe(viewport);
  new ResizeObserver(()=>{const w=viewport.clientWidth,h=viewport.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.fov=w<760?82:60;camera.updateProjectionMatrix();renderer.render(scene,camera);}).observe(viewport);
  viewport.classList.add('is-holographic');
  // The HTML links remain keyboard accessible and turn the matching panel to the viewer.
  links.forEach((link,i)=>link.addEventListener('focus',()=>{target=i*angleStep;idleUntil=performance.now()+4000;}));
  function hit(event){const box=canvas.getBoundingClientRect();pointer.set((event.clientX-box.left)/box.width*2-1,-(event.clientY-box.top)/box.height*2+1);raycaster.setFromCamera(pointer,camera);return raycaster.intersectObjects(cards,false)[0];}
  let flight=null;
  function approach(card,link){
    if(flight)return;
    const prefs=preferences();
    if(prefs.paused||prefs.reduced){location.assign(link.href);return;}
    // Freeze the room and fly the actual etched glass panel into camera space.
    const halfFov=THREE.MathUtils.degToRad(camera.fov/2);
    const distance=Math.max(2.5,1.75/camera.aspect)/Math.tan(halfFov);
    const end=ring.worldToLocal(camera.localToWorld(new THREE.Vector3(0,0,-distance)));
    const facing=ring.getWorldQuaternion(new THREE.Quaternion()).invert().multiply(camera.quaternion);
    flight={card,link,start:performance.now(),origin:card.position.clone(),
      rotation:card.quaternion.clone(),end,facing};
    viewport.dataset.approaching=link.pathname;
    target=offset;
  }
  function animateApproach(now){
    if(flight.leaving)return;
    const {card,link,start,origin,rotation,end,facing}=flight;
    const t=Math.min(1,(now-start)/850);
    const ease=t*t*(3-2*t);
    card.position.lerpVectors(origin,end,ease);
    card.position.y+=.24*Math.sin(Math.PI*t);
    card.quaternion.slerpQuaternions(rotation,facing,ease);
    card.material.opacity=1;
    card.userData.scattering.uniforms.spread.value=.48*Math.sin(Math.PI*t);
    renderer.render(scene,camera);
    if(t===1||preferences().reduced||preferences().paused){
      flight.leaving=true;
      location.assign(link.href);
    }
  }
  links.forEach((link,index)=>link.addEventListener('click',event=>{
    if(event.ctrlKey||event.metaKey||event.shiftKey||event.altKey)return;
    event.preventDefault();
    const matches=cards.filter(card=>card.userData.link===index);
    const closest=matches.reduce((best,card)=>card.getWorldPosition(new THREE.Vector3()).z<
      best.getWorldPosition(new THREE.Vector3()).z?card:best);
    approach(closest,link);
  }));
  addEventListener('pageshow',()=>{
    if(!flight)return;
    flight.card.position.copy(flight.origin);flight.card.quaternion.copy(flight.rotation);
    flight=null;delete viewport.dataset.approaching;
  });
  canvas.addEventListener('pointerdown',event=>{if(event.button!==0||flight)return;down={x:event.clientX,y:event.clientY,base:target,moved:false};canvas.setPointerCapture(event.pointerId);});
  canvas.addEventListener('pointermove',event=>{
    if(down){const dx=event.clientX-down.x;if(Math.abs(dx)>6)down.moved=true;target=down.base+dx*(event.pointerType==="touch"?.011:.007);}
    else {
      canvas.style.cursor=hit(event)?'pointer':'grab';
      if(event.pointerType==='mouse')gaze.copy(pointer);
    }
  });
  canvas.addEventListener('pointerup',event=>{
    if(!down)return;
    const moved=down.moved;down=null;idleUntil=performance.now()+1800;
    if(moved){movedAt=performance.now();return;}
    const object=hit(event)?.object;if(object)approach(object,links[object.userData.link]);
  });
  canvas.addEventListener('pointercancel',()=>down=null);
  canvas.addEventListener('wheel',event=>{if(Math.abs(event.deltaX)>Math.abs(event.deltaY)||event.shiftKey){event.preventDefault();target+=(event.deltaX||event.deltaY)*.002;idleUntil=performance.now()+1800;}},{passive:false});
  viewport.addEventListener('keydown',event=>{if(!['ArrowLeft','ArrowRight'].includes(event.key))return;event.preventDefault();target+=(event.key==='ArrowLeft'?-1:1)*angleStep;idleUntil=performance.now()+2500;});
  document.querySelectorAll('[data-carousel-step]').forEach(button=>button.addEventListener('click',()=>{target+=Number(button.dataset.carouselStep)*angleStep;idleUntil=performance.now()+2000;}));
  function draw(now){
    requestAnimationFrame(draw);if(now-last<(window.beoLite?40:25))return;const dt=Math.min(60,now-last);last=now;
    if(document.hidden)return;
    if(flight){animateApproach(now);return;}
    if(!visible)return;
    if(!down&&!preferences().paused&&!preferences().reduced&&now>idleUntil&&!document.querySelector('#site-menu').open)target+=dt*.000055;
    const motionAllowed=!preferences().paused&&!preferences().reduced;
    if(motionAllowed)eye.lerp(gaze,1-Math.exp(-dt*.012));
    else eye.set(0,0);
    camera.position.set(eye.x*.32,.15+eye.y*.18,.25);
    camera.lookAt(eye.x*2.9,.05+eye.y*1.35,-6);
    offset+=(target-offset)*(1-Math.exp(-dt*.013));ring.rotation.y=offset;
    cards.forEach((card,i)=>{
      const alignment=Math.cos(i*angleStep-offset);
      const spread=preferences().reduced?0:THREE.MathUtils.smoothstep(1-alignment,.055,.41);
      card.userData.scattering.uniforms.spread.value=spread;
      card.material.opacity=1-spread*.61;
    });
    renderer.render(scene,camera);
    viewport.dataset.rotation=offset.toFixed(4);
  }requestAnimationFrame(draw);
  addEventListener('pagehide',()=>{textures.forEach(texture=>texture.dispose());renderer.dispose();},{once:true});
}
