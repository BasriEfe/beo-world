// ---------------------------------------------------------------------------
// hobby-icons.js — Hakkımda > İlgi alanlarım
// Oynat düğmesine ya da ikona basınca kart kısa bir ikon animasyonu oynatır.
// (Eski 3B obje sahnesinin yerini alır.)
// ---------------------------------------------------------------------------
document.querySelectorAll('.hobby-card').forEach(card=>{
  const play=()=>{
    const p=window.beoPreferences||{};if(p.reduced||p.paused)return;
    card.classList.remove('is-playing');void card.offsetWidth;card.classList.add('is-playing');
    setTimeout(()=>card.classList.remove('is-playing'),1700);
  };
  card.querySelector('.hobby-play')?.addEventListener('click',play);
  card.querySelector('.hobby-visual')?.addEventListener('click',play);
});
