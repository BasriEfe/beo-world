import * as THREE from '../vendor/three.module.js';

export function createRoom(scene){
  const vertexShader=`varying vec3 point;
    void main(){vec4 p=modelMatrix*vec4(position,1.);point=p.xyz;
    gl_Position=projectionMatrix*viewMatrix*p;}`;
  function surface(geometry,fragment,options={}){
    const material=new THREE.ShaderMaterial({vertexShader,
      fragmentShader:'varying vec3 point;\n'+fragment,...options});
    const mesh=new THREE.Mesh(geometry,material);
    scene.add(mesh);
    return mesh;
  }
  const floor=surface(new THREE.CircleGeometry(15.25,96),`
    void main(){
      vec2 p=point.xz;float r=length(p);float a=atan(p.x,p.y);
      vec2 cell=abs(fract((p+.21)/2.8)-.5)*2.;
      vec2 aa=max(fwidth(cell),vec2(.001));
      float seam=max(smoothstep(1.-aa.x*1.4,1.,cell.x),smoothstep(1.-aa.y*1.4,1.,cell.y));
      float bay=pow(.5+.5*cos(16.*a),3.);
      float bounce=exp(-.32*abs(r-12.5));
      vec3 slab=mix(vec3(.033,.064,.093),vec3(.135,.21,.25),bounce*(.52+.48*bay));
      slab+=vec3(.04,.085,.105)*bay*smoothstep(3.,11.,r);
      slab*=1.-seam*.5;
      gl_FragColor=vec4(slab,1.);
    }`,{depthWrite:false});
  floor.rotation.x=-Math.PI/2;floor.position.y=-2.61;
  const ceiling=new THREE.Mesh(new THREE.CircleGeometry(15.3,96),
    new THREE.MeshStandardMaterial({color:0x263245,roughness:.76}));
  ceiling.rotation.x=Math.PI/2;ceiling.position.y=7.6;scene.add(ceiling);
  scene.add(new THREE.HemisphereLight(0xd7e6fa,0x758698,1.35));
  const key=new THREE.DirectionalLight(0xffd9b7,2.1);key.position.set(-6,4,-5);scene.add(key);
  const steel=new THREE.MeshStandardMaterial({color:0x374959,roughness:.38,metalness:.32});
  const bronze=new THREE.MeshStandardMaterial({color:0x958878,roughness:.4,metalness:.35});
  function band(radius,y,height,material){
    const wall=new THREE.Mesh(new THREE.CylinderGeometry(radius,radius,height,96,1,true),material);
    material.side=THREE.DoubleSide;wall.position.y=y;scene.add(wall);
  }
  band(14.35,-2.35,.52,steel);
  band(14.28,-2.09,.055,bronze);
  band(14.34,7.12,1.,steel);
  // Repeated solid mullions and ceiling fins share their draw calls.
  const bays=16, matrix=new THREE.Object3D();
  function ribs(width,height,depth,radius,y,material){
    const batch=new THREE.InstancedMesh(new THREE.BoxGeometry(width,height,depth),material,bays);
    for(let i=0;i<bays;i++){
      const a=i*2*Math.PI/bays;
      matrix.position.set(Math.sin(a)*radius,y,Math.cos(a)*radius);
      matrix.rotation.y=a;matrix.updateMatrix();batch.setMatrixAt(i,matrix.matrix);
    }
    scene.add(batch);
  }
  ribs(.13,10.22,.38,14.24,2.5,steel);
  ribs(.026,8.71,.05,14.03,2.26,bronze);
  ribs(.22,.3,6.8,10.85,7.23,steel);
  function cove(radius,y,thickness,color){
    const lamp=new THREE.Mesh(new THREE.TorusGeometry(radius,thickness,8,144),
      new THREE.MeshBasicMaterial({color}));
    lamp.rotation.x=Math.PI/2;lamp.position.y=y;scene.add(lamp);
  }
  cove(14.19,6.62,.018,0xa7d9d7);
  cove(14.17,-2.49,.024,0x75c9df);
  cove(8.35,7.04,.05,0xb3dbe4);
}
