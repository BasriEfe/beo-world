const clamp=value=>Math.max(0,Math.min(1,value));
const smooth=value=>{const t=clamp(value);return t*t*t*(t*(t*6-15)+10);};
const out=value=>1-(1-clamp(value))**4;

export function sampleChapter(progress,width,height){
  const p=clamp(progress),wipe=smooth((p-.16)/.72);
  const edge=(height+80)*(1-wipe)-110*wipe;
  const curve=Math.sin(wipe*Math.PI)*height*.28;
  const horizon=`M 0 ${edge-curve} Q ${width*.5} ${edge+curve} ${width} ${edge-curve}`;
  return {
    progress:p,wipe,orbit:smooth(p),edge,curve,horizon,
    mask:`M 0 -1 H ${width} V ${edge-curve} Q ${width*.5} ${edge+curve} 0 ${edge-curve} Z`,
    copy:1-smooth(p/.38),arrival:out((p-.34)/.46),foot:out((p-.65)/.3)
  };
}

export function playFlight({direction,intro,categories,onCovered,onFinished}){
  if(!CSS.supports('clip-path',"path('M 0 0 H 1 V 1 Z')")){onCovered();onFinished();return;}
  const hero=intro.querySelector('.hero'),sky=document.querySelector('#space-background');
  const width=innerWidth,height=innerHeight,rect=hero.getBoundingClientRect();
  const top=direction==='down'?Math.max(0,rect.top):parseFloat(getComputedStyle(document.querySelector('main')).paddingTop);
  const layer=document.createElement('div');layer.className='chapter-orbit';layer.setAttribute('aria-hidden','true');
  const heroSlot=document.createComment('entrance'),skySlot=document.createComment('sky');
  hero.before(heroSlot);sky.before(skySlot);intro.append(layer);layer.append(sky,hero);
  const styles=new Map(),inert=[hero.inert,categories.inert];
  const remember=element=>{if(!styles.has(element))styles.set(element,element.getAttribute('style'));return element.style;};
  Object.assign(remember(hero),{position:'absolute',top:`${top}px`,left:`${rect.left}px`,width:`${rect.width}px`,height:`${rect.height}px`,maxWidth:'none',margin:'0'});
  const focusWasInSource=(direction==='down'?hero:categories).contains(document.activeElement);
  hero.inert=true;categories.inert=true;
  const copy=hero.querySelector('.hero-copy'),world=hero.querySelector('.world-stage');
  const details=[...hero.querySelectorAll('.scroll-cue,.hero-edition,.world-label,.world-coordinate')];
  // Hedef bölüm eski cam karuseli (.category-viewport) ya da yeni Keşfet ızgarası (.kesfet-grid) olabilir.
  const heading=categories.querySelector('.section-heading'),viewport=categories.querySelector('.category-viewport,.kesfet-index'),foot=categories.querySelector('.carousel-foot');
  const cards=[...categories.querySelectorAll('.category,[data-arrive]')].filter(card=>{const r=card.getBoundingClientRect();return r.right>0&&r.left<width;});
  cards.forEach(card=>{remember(card).willChange='transform,opacity';const stage=card.querySelector('.object-stage');if(stage)remember(stage).willChange='transform';});
  if(viewport)Object.assign(remember(viewport),{transform:'none',opacity:'1'});
  const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.classList.add('chapter-horizon');svg.setAttribute('viewBox',`0 0 ${width} ${height}`);svg.setAttribute('aria-hidden','true');
  const rim=document.createElementNS(svg.namespaceURI,'path');svg.append(rim);intro.append(svg);
  const motion={progress:direction==='down'?0:1,orbit:direction==='down'?0:1};
  window.beoChapter=motion;
  let committed=false,finished=false,request=0,elapsed=0,last=performance.now();
  const duration=direction==='down'?1550:1400;
  function commit(){if(!committed){committed=true;onCovered();}}
  function paint(progress){
    const frame=sampleChapter(progress,width,height),p=frame.progress;
    motion.progress=p;motion.orbit=frame.orbit;
    intro.dataset.transitionProgress=p.toFixed(3);
    const radius=Math.hypot(width,height)*.54*(1-smooth((p-.12)/.76));
    layer.style.clipPath=`circle(${radius}px at 50% 50%)`;
    rim.setAttribute('d',frame.horizon);svg.style.opacity='0';
    Object.assign(remember(copy),{opacity:String(frame.copy),transform:`translate3d(0,${-out(p/.6)*62}px,0)`});
    Object.assign(remember(world),{opacity:'1',transform:`translate3d(${-width*.065*frame.orbit}px,${-height*.055*frame.orbit}px,0) scale(${1+frame.orbit*.12})`});
    const approach=smooth((p-.24)/.76);
    if(viewport)Object.assign(remember(viewport),{opacity:String(approach),transform:`perspective(1100px) translateZ(${-190*(1-approach)}px) rotateY(${-9*(1-approach)}deg)`});
    details.forEach(element=>remember(element).opacity=String(1-smooth(p/.24)));
    if(heading)Object.assign(remember(heading),{opacity:String(frame.arrival),transform:`translate3d(0,${(1-frame.arrival)*42}px,0)`});
    cards.forEach((card,index)=>{
      const arrival=out((p-.38-Math.min(index,4)*.045)/.4);
      Object.assign(remember(card),{opacity:String(arrival),transform:`translate3d(0,${(1-arrival)*70}px,0)`});
      const stage=card.querySelector('.object-stage');if(stage)Object.assign(remember(stage),{transform:`scale(${.96+arrival*.04})`,transformOrigin:'50% 100%'});
    });
    if(foot)Object.assign(remember(foot),{opacity:String(frame.foot),transform:`translate3d(0,${(1-frame.foot)*16}px,0)`});
  }
  function finish(){
    if(finished)return;finished=true;cancelAnimationFrame(request);commit();
    heroSlot.replaceWith(hero);skySlot.replaceWith(sky);layer.remove();svg.remove();
    styles.forEach((style,element)=>{if(style===null)element.removeAttribute('style');else element.setAttribute('style',style);});
    [hero.inert,categories.inert]=inert;delete window.beoChapter;
    removeEventListener('resize',finish);removeEventListener('beo-preferences',preferences);removeEventListener('pagehide',finish);
    onFinished();
    if(focusWasInSource){
      const target=direction==='down'?categories.querySelector('h2'):hero.querySelector('.scroll-cue');
      const tabIndex=target.getAttribute('tabindex');target.setAttribute('tabindex','-1');target.focus({preventScroll:true});
      if(tabIndex===null)target.removeAttribute('tabindex');else target.setAttribute('tabindex',tabIndex);
    }
  }
  function preferences(){if(window.beoPreferences?.paused||window.beoPreferences?.reduced)finish();}
  function tick(now){
    if(finished)return;
    // Hidden tabs resume from the same frame instead of skipping the sequence.
    if(!document.hidden)elapsed+=Math.min(48,now-last);
    last=now;const progress=clamp(elapsed/duration);paint(direction==='down'?progress:1-progress);
    if(progress===1)finish();else request=requestAnimationFrame(tick);
  }
  addEventListener('resize',finish);addEventListener('beo-preferences',preferences);addEventListener('pagehide',finish,{once:true});
  paint(motion.progress);
  if(direction==='down')commit();
  request=requestAnimationFrame(tick);
}
