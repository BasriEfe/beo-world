// ---------------------------------------------------------------------------
// contact-studio.js — İletişim sayfası: çoklu imleç sahnesi
// Beş imleç (Çizim, Ekran, Kurulum, Yazı, Aktarım) birlikte bir telefon ve bir
// monitör kurar, üç iletişim uygulamasını yükler; numara, e-posta ve Instagram
// ekranlarını hazırlayıp her birini monitöre ayrı bir pencere olarak aktarır.
// "Animasyonu geç" doğrudan son hâle götürür; "Tekrar oynat" baştan başlatır.
// Sahne 1200x720 birimlik sabit bir koordinat sisteminde çizilir ve ekrana
// göre ölçeklenir.
// ---------------------------------------------------------------------------
const studio=document.querySelector('.studio');
if(studio){
const stage=studio.querySelector('.studio-stage');
const scene=studio.querySelector('.scene');
const status=studio.querySelector('#studio-status');
const skipBtn=studio.querySelector('.studio-skip');
const replayBtn=studio.querySelector('.studio-replay');
const prefs=()=>window.beoPreferences||{};
const tr=()=>(prefs().language||'tr')==='tr';
const W=1200,H=720;
const $=sel=>scene.querySelector(sel);
const cur=Object.fromEntries([...scene.querySelectorAll('.cur')].map(el=>[el.dataset.cur,{el,x:-80,y:-80}]));
const lines=[...scene.querySelectorAll('.ln')];

// --- Ölçekleme: sahne kapsayıcıya sığar; dar ekranda pencereler aşağıdaki "dock"ta okunur
let scale=1;
function fit(){
  const narrow=stage.clientWidth<760;
  scale=stage.clientWidth/W;
  // Geniş ekranda sahne, kaydırmadan tamamı görünecek şekilde ekran yüksekliğine de sığdırılır.
  if(!narrow){const top=stage.getBoundingClientRect().top+scrollY,avail=innerHeight-top-20;scale=Math.min(scale,Math.max(.5,avail/H));}
  const left=Math.max(0,(stage.clientWidth-W*scale)/2);
  scene.style.transform=`translate(${left}px,0) scale(${scale})`;
  stage.style.height=`${H*scale}px`;
  studio.classList.toggle('is-narrow',narrow);
  // Aynı pencereler iki yerde var: geniş ekranda monitördekiler, dar ekranda dock'takiler kullanılır.
  scene.querySelector('.m-wins').inert=narrow;
  studio.querySelector('.contact-dock').inert=!narrow;
}
new ResizeObserver(fit).observe(stage);addEventListener('resize',fit);fit();

// --- Zamanlama yardımcıları (iptal edilebilir)
let run=0;
class Stop extends Error{}
const live=id=>{if(id!==run)throw new Stop();};
const sleep=(ms,id)=>new Promise((res,rej)=>setTimeout(()=>id===run?res():rej(new Stop()),ms));
const ease=t=>t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2;
const rand=(a,b)=>a+Math.random()*(b-a);
const frame=()=>new Promise(r=>requestAnimationFrame(r));
function place(c){c.el.style.transform=`translate(${c.x}px,${c.y}px)`;}

// Sahne içindeki bir öğenin kutusu (sahne birimlerinde)
function box(el){
  const s=scene.getBoundingClientRect(),r=el.getBoundingClientRect();
  return {x:(r.left-s.left)/scale,y:(r.top-s.top)/scale,w:r.width/scale,h:r.height/scale};
}
const center=el=>{const b=box(el);return [b.x+b.w/2,b.y+b.h/2];};

// İnsan gibi hareket: hafif kavisli yol, hedefe yaklaşırken yavaşlama, küçük bir düzeltme
async function move(c,x,y,id,ms,settle=true){
  const x0=c.x,y0=c.y,dist=Math.hypot(x-x0,y-y0);
  ms=ms??Math.min(900,200+dist*.8)*rand(.85,1.15);
  const bend=rand(-.18,.18)*dist,nx=-(y-y0)/(dist||1),ny=(x-x0)/(dist||1);
  const cx=(x0+x)/2+nx*bend,cy=(y0+y)/2+ny*bend;
  // Hassas hareketlerde önce biraz ıskalar ve düzeltir; hızlı tuşlamada doğrudan gider.
  const ox=settle?x+rand(-6,6):x,oy=settle?y+rand(-5,5):y;
  const t0=performance.now();
  for(;;){
    live(id);const p=Math.min(1,(performance.now()-t0)/ms),e=ease(p);
    c.x=(1-e)*(1-e)*x0+2*(1-e)*e*cx+e*e*ox;c.y=(1-e)*(1-e)*y0+2*(1-e)*e*cy+e*e*oy;place(c);
    if(p>=1)break;await frame();
  }
  if(!settle)return;
  await sleep(rand(40,110),id);
  const t1=performance.now();
  for(;;){live(id);const p=Math.min(1,(performance.now()-t1)/140);c.x=ox+(x-ox)*p;c.y=oy+(y-oy)*p;place(c);if(p>=1)break;await frame();}
}
async function moveTo(c,el,id,ms,dx=0,dy=0,settle=true){const [x,y]=center(el);await move(c,x+dx,y+dy,id,ms,settle);}
async function click(c,id,ms=150){c.el.classList.add('is-click');await sleep(ms,id);c.el.classList.remove('is-click');}

// Çizgiyi imleç ucuyla birlikte çiz
async function draw(c,path,id,ms){
  const len=path.getTotalLength();const start=path.getPointAtLength(0);
  await move(c,start.x,start.y,id);
  const t0=performance.now();
  for(;;){
    live(id);const p=Math.min(1,(performance.now()-t0)/ms),l=len*p,pt=path.getPointAtLength(l);
    path.style.strokeDashoffset=String(len-l);c.x=pt.x;c.y=pt.y;place(c);
    if(p>=1)break;await frame();
  }
}
// Seçim kutusu sürükleme
const marquee=$('.marquee');
async function select(c,b,id,ms=800){
  await move(c,b.x,b.y,id);
  marquee.style.cssText=`left:${b.x}px;top:${b.y}px;width:0;height:0;opacity:1`;
  const t0=performance.now();
  for(;;){
    live(id);const p=ease(Math.min(1,(performance.now()-t0)/ms));
    c.x=b.x+b.w*p;c.y=b.y+b.h*p;place(c);marquee.style.width=`${b.w*p}px`;marquee.style.height=`${b.h*p}px`;
    if(p>=1)break;await frame();
  }
  await sleep(160,id);marquee.style.opacity='0';
}
// Yazı yazma: gerçekçi, düzensiz ritim
async function type(el,text,id,base=70){
  for(const ch of text){live(id);el.textContent+=ch;await sleep(base*rand(.5,1.6)+(ch===' '?60:0),id);}
}
function screen(name){scene.querySelectorAll('.ps').forEach(s=>s.classList.toggle('is-on',s.classList.contains('ps-'+name)));}

// Telefondan monitöre aktarım: telefon ekranının kopyası kavis çizerek hedef pencereye uçar
async function transfer(kind,id){
  const from=box($('.phone-screen')),win=$(`.m-wins [data-win="${kind}"]`),to=box(win);
  const beam=$('#ln-beam');
  const fx=from.x+from.w/2,fy=from.y+from.h/2,tx=to.x+to.w/2,ty=to.y+to.h/2;
  beam.setAttribute('d',`M${fx} ${fy}Q${(fx+tx)/2} ${Math.min(fy,ty)-160} ${tx} ${ty}`);
  const len=beam.getTotalLength();beam.style.strokeDasharray=`${len}`;beam.style.strokeDashoffset=`${len}`;beam.style.opacity='1';
  const ghost=win.cloneNode(true);ghost.classList.add('ghost');ghost.removeAttribute('aria-labelledby');
  ghost.querySelectorAll('[id]').forEach(n=>n.removeAttribute('id'));
  Object.assign(ghost.style,{left:`${from.x}px`,top:`${from.y}px`,width:`${from.w}px`,height:`${from.h}px`});
  scene.append(ghost);
  const s=cur.send,ms=1000,t0=performance.now();
  const anim=ghost.animate([
    {left:`${from.x}px`,top:`${from.y}px`,width:`${from.w}px`,height:`${from.h}px`,borderRadius:'30px',opacity:.35},
    {left:`${(from.x+to.x)/2}px`,top:`${Math.min(from.y,to.y)-120}px`,width:`${(from.w+to.w)/2}px`,height:`${(from.h+to.h)/2}px`,borderRadius:'18px',opacity:.9,offset:.5},
    {left:`${to.x}px`,top:`${to.y}px`,width:`${to.w}px`,height:`${to.h}px`,borderRadius:'10px',opacity:1}
  ],{duration:ms,easing:'cubic-bezier(.45,.05,.25,1)',fill:'forwards'});
  for(;;){ // Aktarım imleci pencereyi taşıyor gibi kopyanın sol üstünü tutar; ışın da birlikte çizilir
    if(id!==run){anim.cancel();ghost.remove();throw new Stop();}
    const p=Math.min(1,(performance.now()-t0)/ms),g=box(ghost);
    s.x=g.x+22;s.y=g.y+14;place(s);beam.style.strokeDashoffset=String(len*(1-ease(p)));
    if(p>=1)break;await frame();
  }
  win.classList.add('is-on');studio.querySelector(`.contact-dock [data-win="${kind}"]`).classList.add('is-on');
  ghost.remove();beam.style.opacity='0';
  scene.dataset.wins=String(scene.querySelectorAll('.m-wins .win.is-on').length);
}


// --- Sayfa başlığı: üç imleç başlığı yazar, altını çizer ve alt metni açar.
// Metin baştan HTML'de durur; burada yalnızca görsel olarak soldan sağa açılır.
const head=document.querySelector('.page-heading');
const headParts=head&&{eyebrow:head.querySelector('.eyebrow'),title:head.querySelector('h1'),lead:head.querySelector('.page-lead')};
const headLayer=document.createElement('div');headLayer.className='head-cursors';headLayer.setAttribute('aria-hidden','true');
const underline=document.createElementNS('http://www.w3.org/2000/svg','svg');underline.classList.add('head-underline');underline.setAttribute('aria-hidden','true');
underline.innerHTML='<path/>';
const hcur={};
if(head){
  head.append(headLayer,underline);
  [['title','#ff9fb8',()=>tr()?'Başlık':'Title'],['line','#7fd18b',()=>tr()?'Çizgi':'Line'],['text','#ffd47a',()=>tr()?'Metin':'Copy']].forEach(([key,color,label])=>{
    const el=document.createElement('div');el.className='cur';el.style.setProperty('--c',color);
    el.innerHTML=`<svg viewBox="0 0 20 22"><path d="M2 2l15 8.5-6.6 1.6-3.4 6.4z"/></svg><span>${label()}</span>`;
    headLayer.append(el);hcur[key]={el,x:-60,y:-60};
  });
}
function hbox(el){const h=head.getBoundingClientRect(),r=el.getBoundingClientRect();return {x:r.left-h.left,y:r.top-h.top,w:r.width,h:r.height};}
function textWidth(el){const range=document.createRange();range.selectNodeContents(el);const r=range.getBoundingClientRect();return r.width||el.getBoundingClientRect().width;}
function hplace(c){c.el.style.transform=`translate(${c.x}px,${c.y}px)`;}
// Başlık alanında imleç hareketi (sahne ölçeği yok, doğrudan piksel)
async function hmove(c,x,y,id,ms){
  const x0=c.x,y0=c.y,t0=performance.now();ms=ms??Math.min(800,200+Math.hypot(x-x0,y-y0)*.7);
  for(;;){live(id);const p=Math.min(1,(performance.now()-t0)/ms),e=ease(p);c.x=x0+(x-x0)*e;c.y=y0+(y-y0)*e-Math.sin(p*Math.PI)*18;hplace(c);if(p>=1)break;await frame();}
}
// Öğeyi soldan sağa aç; imleç açılan kenarı takip eder
async function reveal(c,el,id,ms){
  const b=hbox(el),w=Math.min(b.w,textWidth(el)+4),y=b.y+b.h*.55;
  await hmove(c,b.x,y,id);
  const t0=performance.now();
  for(;;){live(id);const p=Math.min(1,(performance.now()-t0)/ms),e=1-Math.pow(1-p,2);
    el.style.clipPath=`inset(-20% ${100-(e*w/b.w)*100}% -20% 0)`;c.x=b.x+w*e;c.y=y+Math.sin(p*30)*2;hplace(c);if(p>=1)break;await frame();}
  el.style.clipPath='none'; // açık kalsın (başlık kurulumu bitene kadar sınıf gizlemesin)
}
async function buildHeading(id){
  if(!head)return;
  [headParts.title,headParts.lead].forEach(el=>el.style.clipPath='');headParts.eyebrow.classList.remove('is-in');
  underline.querySelector('path').style.strokeDashoffset='9999';
  head.classList.add('is-building');
  Object.values(hcur).forEach(c=>{c.x=-60;c.y=40;hplace(c);c.el.style.opacity='1';});
  const {title,line,text}=hcur;
  // Başlık imleci etiketi tıklar ve başlığı yazar
  const e=hbox(headParts.eyebrow);await hmove(title,e.x+20,e.y+6,id,500);
  title.el.classList.add('is-click');await sleep(120,id);title.el.classList.remove('is-click');headParts.eyebrow.classList.add('is-in');
  await Promise.all([
    reveal(title,headParts.title,id,1100),
    (async()=>{ // Çizgi imleci başlığın altını çizer
      await sleep(700,id);
      const b=hbox(headParts.title),w=Math.min(b.w,textWidth(headParts.title)),y=b.y+b.h+10;
      const path=underline.querySelector('path');path.setAttribute('d',`M${b.x} ${y}C${b.x+w*.3} ${y+6} ${b.x+w*.7} ${y-4} ${b.x+w} ${y+2}`);
      const len=path.getTotalLength();path.style.strokeDasharray=`${len}`;path.style.strokeDashoffset=`${len}`;
      await hmove(line,b.x,y,id,500);const t0=performance.now();
      for(;;){live(id);const p=Math.min(1,(performance.now()-t0)/650),pt=path.getPointAtLength(len*p);path.style.strokeDashoffset=String(len*(1-p));line.x=pt.x;line.y=pt.y;hplace(line);if(p>=1)break;await frame();}
    })(),
    (async()=>{await sleep(900,id);await reveal(text,headParts.lead,id,800);})()
  ]);
  head.classList.remove('is-building');
  // Başlık imleçleri aşağıdaki sahneye doğru süzülüp kaybolur
  Object.values(hcur).forEach((c,i)=>{hmove(c,c.x+60+i*30,head.offsetHeight+80,id,900).catch(()=>{});setTimeout(()=>c.el.style.opacity='0',500);});
}
function finishHeading(){
  if(!head)return;head.classList.remove('is-building');
  [headParts.title,headParts.lead].forEach(el=>el.style.clipPath='');headParts.eyebrow.classList.add('is-in');
  const path=underline.querySelector('path');
  if(!path.getAttribute('d')){const b=hbox(headParts.title),w=Math.min(b.w,textWidth(headParts.title)),y=b.y+b.h+10;path.setAttribute('d',`M${b.x} ${y}C${b.x+w*.3} ${y+6} ${b.x+w*.7} ${y-4} ${b.x+w} ${y+2}`);}
  path.style.strokeDasharray='none';path.style.strokeDashoffset='0';
  Object.values(hcur).forEach(c=>c.el.style.opacity='0');
}

// --- Başlangıç ve son hâller
function reset(){
  lines.forEach(p=>{const l=p.getTotalLength();p.style.strokeDasharray=`${l}`;p.style.strokeDashoffset=`${l}`;});
  scene.className='scene';scene.dataset.wins='0';
  scene.querySelectorAll('.win,.app').forEach(n=>n.classList.remove('is-on','is-installing','is-done'));
  studio.querySelectorAll('.contact-dock .win').forEach(n=>n.classList.remove('is-on'));
  scene.querySelectorAll('.dial-num,.t-to,.t-sub,.t-body,.t-search').forEach(n=>n.textContent='');
  $('.insta-profile').classList.remove('is-on');screen('home');
  Object.values(cur).forEach((c,i)=>{c.x=[-60,1260,600,-60,1260][i];c.y=[200,140,780,600,620][i];place(c);c.el.classList.remove('is-idle');});
  marquee.style.opacity='0';
}
function finish(){
  run++;finishHeading();
  lines.forEach(p=>{p.style.strokeDashoffset='0';});
  scene.classList.add('has-phone','has-monitor','has-screen','has-wallpaper','has-notch','apps-ready','is-final');
  scene.querySelectorAll('.app').forEach(a=>a.classList.add('is-done'));
  scene.querySelectorAll('.win').forEach(w=>w.classList.add('is-on'));
  studio.querySelectorAll('.contact-dock .win').forEach(w=>w.classList.add('is-on'));
  scene.dataset.wins='3';screen('home');marquee.style.opacity='0';$('#ln-beam').style.opacity='0';
  scene.querySelectorAll('.ghost').forEach(g=>g.remove());
  // İmleçler kenara çekilip sakin bekler
  [[300,40],[1180,30],[40,700],[372,690],[1185,560]].forEach(([x,y],i)=>{const c=Object.values(cur)[i];c.x=x;c.y=y;place(c);c.el.classList.add('is-idle');});
  skipBtn.hidden=true;replayBtn.hidden=false;
  status.textContent=tr()?'İletişim pencereleri hazır.':'The contact windows are ready.';
}

// --- Senaryo
async function play(){
  const id=++run;reset();skipBtn.hidden=false;replayBtn.hidden=true;
  status.textContent=tr()?'Sahne kuruluyor. Animasyonu geçebilirsin.':'Building the scene. You can skip the animation.';
  const {draw:A,frame:B,setup:Cs,type:T,send:S}=cur;
  try{
    buildHeading(id).catch(error=>{if(!(error instanceof Stop))console.warn(error);});
    // 1) Telefon ve monitör çizilir
    await Promise.all([
      (async()=>{await draw(A,$('#ln-phone'),id,1500);scene.classList.add('has-phone');
        await move(A,225,150,id);await click(A,id);scene.classList.add('has-notch');await move(A,40,90,id);A.el.classList.add('is-idle');})(),
      (async()=>{await sleep(250,id);await draw(B,$('#ln-monitor'),id,1800);await draw(B,$('#ln-stand'),id,600);scene.classList.add('has-monitor');
        await select(B,{x:400,y:80,w:740,h:416},id,650);scene.classList.add('has-wallpaper');})(),
      (async()=>{await sleep(1600,id);await select(Cs,{x:106,y:128,w:238,h:528},id,650);scene.classList.add('has-screen');})()
    ]);
    // 2) Üç uygulama kurulur: başlangıç, ilerleme, tamamlanma
    const apps=[...scene.querySelectorAll('.app')],installs=[];
    for(const app of apps){
      await moveTo(Cs,app.querySelector('.app-pill'),id);await click(Cs,id);
      app.classList.add('is-installing');
      installs.push(sleep(1100,id).then(()=>{app.classList.remove('is-installing');app.classList.add('is-done');}));
      await sleep(rand(150,250),id);
    }
    await Promise.all(installs);scene.classList.add('apps-ready');await sleep(250,id);
    Cs.el.classList.add('is-idle');move(Cs,40,520,id,1400).catch(()=>{});

    // 3) Telefon: numara tuşlanır, arama ekranı monitöre aktarılır
    await moveTo(T,$('.app[data-app="phone"] .app-icon'),id);await click(T,id);screen('dial');await sleep(200,id);
    const num=$('.dial-num'),digits=num.closest('.ps').querySelector('.dial-keys');
    const display=document.querySelector('.win-phone .win-big').textContent.trim();
    for(const ch of display){
      if(ch===' '){num.textContent+=' ';continue;}
      const key=digits.querySelector(`[data-k="${ch}"]`);
      // Hızlı ama insan gibi: tuşlar arası kısa ve düzensiz geçişler
      await moveTo(T,key,id,rand(110,180),0,0,false);await click(T,id,90);key.classList.add('is-hit');setTimeout(()=>key.classList.remove('is-hit'),160);
      num.textContent+=ch;await sleep(rand(20,70),id);
    }
    await moveTo(S,$('.ps-dial .ps-send'),id);await click(S,id);await transfer('phone',id);

    // 4) Mail: adres ve kısa bir ileti yazılır, ikinci pencere olarak aktarılır
    await moveTo(T,$('.ps-homebar'),id);await click(T,id);screen('home');await sleep(180,id);
    await moveTo(T,$('.app[data-app="mail"] .app-icon'),id);await click(T,id);screen('mail');await sleep(180,id);
    const mail=document.querySelector('.win-mail .mail-form').dataset.to;
    await moveTo(T,$('.t-to'),id,undefined,-60,0);await click(T,id);await type($('.t-to'),mail,id,32);
    await moveTo(T,$('.t-sub'),id,undefined,-60,0);await click(T,id);await type($('.t-sub'),tr()?'Merhaba Efe':'Hi Efe',id,45);
    await moveTo(T,$('.t-body'),id,undefined,-70,-6);await click(T,id);await type($('.t-body'),tr()?'Sitene baktım, konuşalım mı?':'Saw your site, shall we talk?',id,28);
    await moveTo(S,$('.ps-mail .ps-send'),id);await click(S,id);await transfer('mail',id);

    // 5) Instagram: kullanıcı adı aranır, profil açılır, üçüncü pencere aktarılır
    await moveTo(T,$('.ps-homebar'),id);await click(T,id);screen('home');await sleep(180,id);
    await moveTo(T,$('.app[data-app="insta"] .app-icon'),id);await click(T,id);screen('insta');await sleep(180,id);
    await moveTo(T,$('.insta-search'),id);await click(T,id);
    const handle=document.querySelector('.win-insta .win-big').textContent.trim().replace('@','');
    await type($('.t-search'),handle,id,55);await sleep(150,id);$('.insta-profile').classList.add('is-on');await sleep(350,id);
    await moveTo(S,$('.ps-insta .ps-send'),id);await click(S,id);await transfer('insta',id);

    // 6) Final: telefon ana ekrana döner, imleçler kenara çekilir
    await moveTo(T,$('.ps-homebar'),id);await click(T,id);screen('home');await sleep(300,id);
    finish();
  }catch(error){if(!(error instanceof Stop))throw error;}
}

// --- Kontroller
skipBtn.addEventListener('click',()=>{finish();replayBtn.focus({preventScroll:true});});
replayBtn.addEventListener('click',()=>{if(prefs().reduced||prefs().paused){finish();return;}play();});

// Kopyalama ve e-posta taslağı (bilinçli tıklamayla)
studio.addEventListener('click',async event=>{
  const btn=event.target.closest('[data-copy]');if(!btn)return;
  const label=btn.querySelector('span'),old=label.textContent;
  try{await navigator.clipboard.writeText(btn.dataset.copy);label.textContent=tr()?'Kopyalandı':'Copied';}
  catch{label.textContent=tr()?'Kopyalanamadı':'Copy failed';}
  setTimeout(()=>label.textContent=old,1600);
});
studio.querySelectorAll('.mail-form').forEach(form=>form.addEventListener('submit',event=>{
  event.preventDefault();if(!form.reportValidity())return;
  const data=new FormData(form);
  location.href=`mailto:${form.dataset.to}?subject=${encodeURIComponent(data.get('subject'))}&body=${encodeURIComponent(data.get('message'))}`;
}));

// Hareket azaltma veya "hareketi durdur" açıksa doğrudan son hâl; yoksa sahne görünür olunca başlar.
reset();
if(prefs().reduced||prefs().paused)finish();
else play(); // Sayfa açılır açılmaz başlar: başlık yazılırken sahne de kurulur.
}
