export function notebook(grid, cards, language) {
  const desk = document.createElement('div');
  desk.className = 'desk-scene';
  grid.before(desk);
  desk.append(grid);
  const controls = document.createElement('nav');
  controls.className = 'book-controls';
  controls.innerHTML = '<button type="button" data-step="-1">←</button><output aria-live="polite"></output><button type="button" data-step="1">→</button>';
  desk.after(controls);
  grid.classList.add('notebook');
  const buttons = [...controls.querySelectorAll('button')];
  let available = [], index = 0, frame = 0, turning = null;

  function draw() {
    cards.forEach(card => card.classList.toggle('book-open', card === available[index]));
    desk.hidden = controls.hidden = !available.length;
    buttons[0].disabled = index === 0;
    buttons[1].disabled = index >= available.length - 1;
    controls.querySelector('output').textContent = (index + 1) + ' / ' + available.length;
    buttons.forEach((button, i) => button.setAttribute('aria-label',
      (language() === 'tr' ? ['Önceki sayfa', 'Sonraki sayfa'] : ['Previous page', 'Next page'])[i]));
    grid.dataset.spread = String(index + 1);
  }
  function cleanup() {
    cancelAnimationFrame(frame);
    turning?.remove();
    turning = null;
    grid.querySelector('.book-underleaf')?.remove();
    delete grid.dataset.turning;
  }
  function print(source, width, height, offset) {
    const paper = document.createElement('div');
    paper.className = 'leaf-print';
    paper.style.cssText = `width:${width}px;height:${height}px;left:${-offset}px`;
    paper.append(source.cloneNode(true));
    return paper;
  }
  function turn(step) {
    const next = index + step;
    if (!available[next] || turning) return;
    const old = available[index];
    index = next;
    draw();
    const prefs = window.beoPreferences;
    if (prefs?.paused || prefs?.reduced) return;
    const width = grid.offsetWidth / 2, height = grid.offsetHeight;
    const forward = step > 0;
    const oldSide = old.querySelector(forward ? '.journal-card-copy' : '.journal-art');
    const newSide = available[index].querySelector(forward ? '.journal-art' : '.journal-card-copy');
    const under = document.createElement('div');
    under.className = 'book-underleaf ' + (forward ? 'left' : 'right');
    under.setAttribute('aria-hidden', 'true');
    under.append(old.querySelector(forward ? '.journal-art' : '.journal-card-copy').cloneNode(true));
    grid.append(under);
    turning = document.createElement('div');
    turning.className = 'curling-page';
    turning.setAttribute('aria-hidden', 'true');
    const count = 40, stripWidth = width / count;
    const strips = Array.from({length: count}, (_, i) => {
      const strip = document.createElement('div');
      strip.className = 'paper-strip';
      strip.style.width = (stripWidth + .65) + 'px';
      for (let face = 0; face < 2; face++) {
        const side = document.createElement('div');
        side.className = 'paper-face ' + (face ? 'back' : 'front');
        const offset = (face === 0 ? forward : !forward) ? i * stripWidth : width - (i + 1) * stripWidth;
        side.append(print(face ? newSide : oldSide, width, height, offset));
        strip.append(side);
      }
      turning.append(strip);
      return strip;
    });
    grid.append(turning);
    grid.dataset.turning = forward ? 'forward' : 'backward';
    const start = performance.now();
    function animate(now) {
      if (!turning) return;
      const preferences = window.beoPreferences;
      const raw = preferences?.paused || preferences?.reduced ? 1 : Math.min(1, (now - start) / 1200);
      const p = raw * raw * (3 - 2 * raw), bend = Math.sin(p * Math.PI);
      let x = 0, z = 0;
      strips.forEach((strip, i) => {
        // Integrating the changing angle keeps the paper continuous along the curl.
        const angle = p * Math.PI + bend * 1.85 * (i / (count - 1) - .42);
        const dx = Math.cos(angle) * stripWidth, dz = Math.sin(angle) * stripWidth;
        const position = forward ? x : -x - dx;
        strip.style.transform = `translate3d(${position}px,${-Math.sin(i / count * Math.PI) * bend * 3}px,${z}px) rotateY(${(forward ? -1 : 1) * angle}rad)`;
        strip.style.setProperty("--leaf-shade", String(bend * (.09 + .23 * Math.abs(Math.sin(angle)))));
        x += dx;
        z += dz;
      });
      under.style.setProperty('--cast-shadow',String(bend*.26));
      grid.dataset.turnProgress = p.toFixed(3);
      if (raw < 1) frame = requestAnimationFrame(animate);
      else cleanup();
    }
    frame = requestAnimationFrame(animate);
  }
  buttons.forEach(button => button.addEventListener('click', () => turn(Number(button.dataset.step))));
  grid.addEventListener('keydown', event => {
    if (!['ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    turn(event.key === 'ArrowLeft' ? -1 : 1);
    available[index]?.querySelector('a')?.focus({preventScroll: true});
  });
  let drag = null;
  let suppressClick = false;
  desk.addEventListener('pointerdown', event => {
    if (!event.isPrimary || event.button !== 0) return;
    suppressClick = false;
    drag = {id: event.pointerId, x: event.clientX, y: event.clientY};
  });
  window.addEventListener('pointermove', event => {
    if (drag?.id !== event.pointerId) return;
    const dx = event.clientX - drag.x;
    const dy = event.clientY - drag.y;
    const threshold = event.pointerType === 'mouse' ? 12 : 18;
    if (Math.abs(dx) < threshold || Math.abs(dx) < Math.abs(dy)) return;
    drag = null;
    suppressClick = true;
    desk.setPointerCapture(event.pointerId);
    turn(dx > 0 ? 1 : -1);
  });
  function endDrag(event) {
    if (drag?.id === event.pointerId) drag = null;
  }
  window.addEventListener('pointerup', endDrag);
  window.addEventListener('pointercancel', endDrag);
  window.addEventListener('blur', () => { drag = null; });
  desk.addEventListener('dragstart', event => event.preventDefault());
  desk.addEventListener('click', event => {
    if (!turning && !(suppressClick && event.detail)) return;
    suppressClick = false;
    event.preventDefault();
    event.stopPropagation();
  }, true);
  addEventListener('resize', cleanup);
  addEventListener('pagehide', cleanup, {once: true});
  return () => {
    cleanup();
    const previous = available[index];
    available = cards.filter(card => !card.hidden);
    index = Math.max(0, available.indexOf(previous));
    draw();
  };
}
